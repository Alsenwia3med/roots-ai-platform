# ROOTS-AI™ — ADM-01 Admin Sign-in and MFA — QA / Implementation Contract

## Scope
ADM-01 — Admin Sign-in and MFA.
4 responsive SVG handoff files: 360 / 768 / 1024 / 1440.

## Locked contract
- Route / entry: `/admin`
- Access: Privileged users
- Purpose: Authenticate privileged users
- Content authority: Master Requirements controls roles, data and audit; C-04 controls system/error copy.
- Brand: admin-only identity.
- Authentication: approved provider authentication.
- MFA: required challenge.
- Recovery: controlled recovery; no security-question fallback.
- Environment: visible Staging/Production badge after authentication.

## State contract
- initial
- auth_loading
- mfa_challenge
- mfa_verification
- permission_denied
- safe_service_error
- session_expired
- authorized_transition

## Security / RBAC
- No public signup.
- No participant/report data.
- No auth tokens, MFA seeds, provider internals or stack traces.
- RBAC authorization occurs before protected admin environment access.
- URL guessing must not reveal protected data.
- Approved recovery only; no security-question fallback.
- Post-auth environment badge must identify Staging or Production.

## Approved C-04 session-expiry copy
“For your security, this session has expired. Request a new secure link to continue.”

## Accessibility
- ≥44 px action targets
- logical keyboard order
- visible focus in implementation
- MFA fields labeled for assistive technology
- failure state announced accessibly
- state meaning must not rely on color alone

## Static QA performed
- XML parse: 4/4 PASS
- CairoSVG static render: 4/4 PASS
- Official Phase 0B ROOTS-AI light-background wordmark embedded
- ZIP integrity: PASS
- Static PNG visual inspection cycle: 360 and 1440
- Initial spacing/overflow issues were corrected before final packaging
- Desktop/tablet post-auth environment containment corrected
- Provider/MFA/recovery labels use approved-copy bindings rather than invented production copy

## Production validation still required
- Browser/staging visual regression at 360/768/1024/1440.
- Approved identity-provider integration.
- MFA positive/negative paths.
- Positive and negative RBAC tests.
- URL-guessing negative tests.
- Session-expiry re-authentication.
- Controlled recovery path.
- Keyboard/focus/screen-reader validation.
- Security/audit logging validation.

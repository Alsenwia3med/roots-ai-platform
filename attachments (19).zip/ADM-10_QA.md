# ROOTS-AI™ — Axis E Access Governance — QA

## Scope
ADM-10 Users and Roles
4 responsive SVG handoff files: 360 / 768 / 1024 / 1440.

## Locked source contract implemented
- Route `/admin/access`; access Super Admin.
- Purpose: manage named privileged access.
- Users: name, email, role, MFA, status, last access.
- Invite: named account and role.
- Change role: required reason + MFA re-auth + confirmation + immutable audit event.
- Revoke: immediate access revocation.
- Implementation access: expiry mandatory; no permanent default.
- No shared privileged account pattern represented.
- No password, MFA secret, token or credential display.

## Shared admin contract
- Desktop optimized; tablet functional; mobile supports urgent review/actions.
- Wide tables may use labeled horizontal scroll where required.
- Only role-authorized actions.
- Every privileged write requires confirmation, reason where stated, and audit event.
- Loading skeleton; permission denied; filtered empty; safe service error; stale-data refresh; session-expiry re-auth.
- Positive/negative RBAC and URL-guessing protection required in production.

## Static QA performed
- XML parse: 4/4 PASS
- CairoSVG render: 4/4 PASS
- Official Phase 0B light-background ROOTS-AI wordmark embedded
- ZIP integrity: PASS
- Static visual QA performed on 360 and 1440
- Mobile implementation-expiry binding containment corrected
- Desktop/tablet change-role MFA-note overlap corrected

## Production validation still required
- Browser/staging visual regression at 360/768/1024/1440.
- Real Super Admin positive/negative RBAC.
- URL guessing negative test.
- Named-account enforcement.
- MFA re-auth enforcement for role changes.
- Immediate revoke enforcement and session invalidation.
- Mandatory implementation-access expiry enforcement.
- Confirmation/reason/audit event behavior.
- Immutable audit evidence.
- Keyboard/focus/screen-reader validation.
- Session-expiry and safe error flows.

# ROOTS-AI™ — Axis C Report & Configuration Operations — QA

## Scope
ADM-05 Report Operations
ADM-06 Configuration Releases
ADM-07 Configuration Detail
12 responsive SVG handoff files: 360 / 768 / 1024 / 1440.

## Locked source contract implemented

### ADM-05
- Route `/admin/reports`; access Admin.
- Filters: Ready / generating / failed, date, version.
- Table: report ID, participant pseudonym, versions, status, timestamps.
- Failure detail: failure code + safe trace reference.
- Actions: retry governed narrative / PDF only.
- Scores are never edited from this screen.
- Audit evidence link represented.

### ADM-06
- Route `/admin/configuration`; access Admin / Super Admin.
- Immutable questionnaire/scoring/template release listing.
- Fields: type, version, state, effective date, publisher, checksum.
- Filters: draft / published / retired and type.
- View / compare represented.
- Publish / rollback explicitly Super Admin only.
- Published releases immutable.

### ADM-07
- Route `/admin/configuration/[version]`; access Admin / Super Admin.
- Header: type / version / state / checksum.
- Current-vs-candidate field-level diff.
- Validation: schema checks + Golden Test.
- Evidence: publisher / approval / timestamps.
- Publish / rollback require reason + MFA re-auth + confirmation + audit.
- No silent edit.

## Shared admin contract
- Desktop optimized; tablet functional; mobile urgent review/actions.
- Wide tables may use labeled horizontal scroll.
- Only role-authorized actions.
- Every privileged write requires confirmation, reason where stated, and audit event.
- Loading skeleton; permission denied; filtered empty; safe service error; stale-data refresh; session-expiry re-auth.
- Positive/negative RBAC and URL-guessing protection required in production.

## Static QA performed
- XML parse: 12/12 PASS
- CairoSVG render: 12/12 PASS
- Official Phase 0B light-background ROOTS-AI wordmark embedded
- ZIP integrity: PASS
- Static visual QA performed on 360 and 1440 for ADM-05/06/07
- ADM-05 mobile detail-drawer action/audit overlap corrected
- ADM-07 mobile controlled-action overlap corrected

## Production validation still required
- Browser/staging visual regression at 360/768/1024/1440.
- Real RBAC positive/negative tests.
- URL guessing negative tests.
- Real report-recovery actions with invariant score protection.
- Safe trace-reference redaction.
- Configuration checksum/diff/schema/Golden Test bindings.
- Super Admin publish/rollback authorization.
- Reason capture + MFA re-auth + confirmation + immutable audit evidence.
- Keyboard/focus/screen-reader validation.
- Session-expiry and safe error flows.

# ROOTS-AI™ — Axis D Governance, Audit & Research — QA

## Scope
ADM-08 Audit Viewer
ADM-09 Research Export
8 responsive SVG handoff files: 360 / 768 / 1024 / 1440.

## Locked source contract implemented

### ADM-08
- Route `/admin/audit`; access Super Admin.
- Purpose: review append-only privileged/security events.
- Filters: actor, action, object, result, date, environment.
- Table: timestamp, actor, action, safe object reference, result.
- Structured metadata detail with secrets/PHI explicitly redacted.
- Approved audit export binding only.
- No delete/edit control.

### ADM-09
- Route `/admin/research-export`; access Research Admin.
- Required approved project/purpose reference.
- Filters restricted to approved cohort/date/consent criteria.
- Allow-listed pseudonymized field preview.
- Risk gate: cell-size + direct-identifier validation.
- Generate action represented as approved binding; output contract is encrypted + expiring + audited.
- History includes requester, purpose, checksum, expiry and audit event.
- No direct identifiers or unrestricted database export.

## Shared admin contract
- Desktop optimized; tablet functional; mobile urgent review/actions.
- Wide tables may use labeled horizontal scroll.
- Only role-authorized actions.
- Every privileged write requires confirmation, reason where stated, and audit event.
- Loading skeleton; permission denied; filtered empty; safe service error; stale-data refresh; session-expiry re-auth.
- Positive/negative RBAC and URL-guessing protection required in production.

## Static QA performed
- XML parse: 8/8 PASS
- CairoSVG render: 8/8 PASS
- Official Phase 0B light-background ROOTS-AI wordmark embedded
- ZIP integrity: PASS
- Static visual QA performed on ADM-08 and ADM-09 at 360 and 1440
- ADM-09 desktop/tablet field-preview note overlap corrected

## Production validation still required
- Browser/staging visual regression at 360/768/1024/1440.
- Real RBAC positive/negative tests.
- URL guessing negative tests.
- PHI/secret redaction tests for audit detail and export pipelines.
- Append-only audit-store verification.
- Approved audit-export authorization.
- Research purpose/cohort/consent allow-list enforcement.
- Cell-size/direct-identifier risk checks with blocked failure states.
- Encryption, expiry and download authorization.
- Checksum/history/audit-event verification.
- Keyboard/focus/screen-reader validation.
- Session-expiry and safe error flows.

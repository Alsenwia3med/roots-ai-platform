# ROOTS-AI™ — Axis B Admin Operations & Participant Management — QA

## Scope
ADM-02 Operations Overview
ADM-03 Participants
ADM-04 Participant Detail
12 responsive SVG handoff files: 360 / 768 / 1024 / 1440.

## Locked source contract implemented
ADM-02: operational dashboard with top metrics, queues, release status, system health, and Super-Admin-only audit preview.
ADM-03: filters limited to status/date/report state; participant table uses pseudonymous/display identity, masked email, status and dates; open detail/resend approved link; no free-text health-answer search; no bulk export; server-side pagination with URL-persisted filters.
ADM-04: minimum necessary identity, lifecycle timeline, assessment completion/version, raw answers only when role/purpose permits, report status/version with secure open/resend, deletion/access request state, logged actions, and no edit of submitted answers.

## Shared admin requirements
- Desktop optimized; tablet functional; mobile supports urgent review/actions.
- Wide tables may use labeled horizontal scroll.
- Only role-authorized actions.
- Every privileged write requires confirmation, reason where stated, and an audit event.
- Loading skeleton; permission denied; filtered empty; safe service error; stale-data refresh; session-expiry re-auth.
- Positive/negative RBAC and URL-guessing protection required in production.
- Immutable audit evidence required for privileged writes.

## Static QA performed
- XML parse: 12/12 PASS
- CairoSVG render: 12/12 PASS
- Official Phase 0B light-background ROOTS-AI wordmark embedded
- ZIP integrity: PASS
- Static PNG visual inspection: ADM-02/03/04 at 360 and 1440
- ADM-02 desktop metric binding overflow corrected
- ADM-04 mobile binding/note wrapping and desktop vertical containment corrected
- ADM-04 desktop/tablet final-note containment expanded

## Production validation still required
- Browser/staging visual regression at all 4 breakpoints.
- Real RBAC positive/negative tests.
- URL guessing negative tests.
- Backend data minimization enforcement.
- Server-side pagination/filter persistence.
- Action confirmation/reason/audit behavior.
- Keyboard/focus/screen-reader validation.
- Session-expiry and safe error flows.

# ROOTS-AI™ — Stage 7 / Axis B — Global Error & Availability Recovery — QA

## Scope
SYS-02 — 404
SYS-03 — 500 / Service Error
SYS-04 — Maintenance
12 responsive SVG handoff files total: 360 / 768 / 1024 / 1440 for each screen.

## Locked source contract implemented
### SYS-02
- Route/entry: Unknown route.
- Access: Any.
- Purpose: recover from unknown route.
- Message: Page not found.
- Actions: Home / Start Assessment / Contact.
- Security: no route diagnostics.

### SYS-03
- Route/entry: Global boundary.
- Access: Any.
- Purpose: recover safely from unexpected failure.
- Message: Unable to complete request.
- Non-sensitive `{{incident_reference}}`.
- Actions: Retry / Home / Contact.
- Client/server correlation without secrets or health content.
- No raw stack traces, tokens, health content or infrastructure detail in UI.

### SYS-04
- Route/entry: Maintenance gate.
- Access: Any.
- Purpose: communicate planned unavailability.
- Maintenance copy bound to `{{approved_maintenance_message}}`.
- Expected return shown only via approved/configured binding.
- Actions: Refresh + configured public status/contact action.
- Admin bypass never public.

## Shared contract
- Full viewport.
- Intended to remain usable at 320 CSS px without clipped primary action.
- Only safe recovery actions listed.
- Every state: visible title, explanation, action and support path where relevant.
- State can be forced in test environment.
- Keyboard/screen-reader behavior and recovery action require production verification.
- C-04 remains authority for exact approved system/error copy; bindings are used where no literal production copy is present.

## Static QA performed
- XML parse: 12/12 PASS.
- CairoSVG render: 12/12 PASS.
- Official Phase 0B light-background ROOTS-AI wordmark embedded.
- ZIP integrity: PASS.
- Static visual QA performed on all three screens at 360 and 1440.
- SYS-03 mobile title/logging overflow corrected.
- SYS-04 mobile configured-action binding fit corrected.

## Production validation still required
- Browser/Staging visual regression at 320/360/768/1024/1440.
- Keyboard-only and screen-reader smoke.
- Visible focus and logical focus order.
- 200% zoom/reflow.
- Force each system state in test environment.
- Verify 404 exposes no route diagnostics.
- Verify 500 incident reference is non-sensitive and correlation logs exclude secrets/health content.
- Verify Retry behavior and failure fallback.
- Verify Maintenance expected-return binding is absent when not approved.
- Verify maintenance public-status/contact action renders only when configured.
- Verify no admin bypass or internal maintenance mechanism is exposed publicly.

# ROOTS-AI™ — Stage 7 / Axis C — SYS-05 Offline / Reconnect — QA

## Scope
SYS-05 — Offline / Reconnect
4 responsive SVG handoff files: 360 / 768 / 1024 / 1440.

## Locked source contract implemented
- Route/entry: Assessment / report / admin overlays.
- Access: Authorized user.
- Purpose: protect work during network loss.
- Offline status banner.
- Assessment:
  - exact C-04 SAVE-FAIL copy included.
  - current unsent input held locally in memory only.
  - retry save.
  - warn before exit.
  - no false Saved state before backend acknowledgement.
- Submitted / Report:
  - never fabricate success.
  - retry authoritative status.
- Admin:
  - writes disabled while offline/stale.
  - fresh authorization/state required before write actions re-enable.
  - no privileged write replay.
- Recovery:
  - reconnect/reconcile state represented.
  - latest confirmed saved timestamp binding included.
  - saved confirmation requires backend acknowledgement.

## Bindings
- `{{approved_offline_status_message}}`
- `{{report_or_submission_connectivity_status}}`
- `{{reconnect_status}}`
- `{{last_confirmed_saved_at}}`
- `{{unsent_input_present}}`

## Security / persistence boundary
- Unsent assessment input: memory only.
- No localStorage/IndexedDB/cookie persistence implied for unsent health answers.
- No fabricated submission/report success.
- No Admin mutation while offline or from stale authorization.
- No automatic replay of privileged writes after reconnect.

## Responsive / accessibility contract
- 360 / 768 / 1024 / 1440 delivered.
- Intended to remain usable at 320 CSS px without clipped primary recovery action.
- Mobile recovery controls are stacked.
- 44px primary action targets represented where applicable.
- Metadata includes WCAG 2.2 AA, keyboard, screen-reader, visible-focus, no-trap and zoom/reflow requirements.

## Static QA performed
- XML parse: 4/4 PASS.
- CairoSVG render: 4/4 PASS.
- Official Phase 0B light-background ROOTS-AI wordmark embedded.
- ZIP integrity: PASS.
- Static visual QA performed on 360, 768, 1024 and 1440.
- 360px reconciliation/exit-warning overlap corrected after visual inspection.

## Production validation still required
- Browser/Staging visual regression at 320/360/768/1024/1440.
- Force offline/reconnect state in assessment, report and admin.
- Confirm assessment unsent input is memory-only and not persisted to localStorage/IndexedDB/cookies.
- Confirm exit/refresh/navigation warning when unsent input exists.
- Confirm Retry Save cannot report success until server acknowledgement.
- Confirm submitted/report status never fabricates success.
- Confirm admin writes remain disabled until fresh authorization/state.
- Confirm privileged writes are not replayed after reconnect.
- Confirm reconciliation displays authoritative last-saved timestamp.
- Keyboard-only, screen-reader, visible-focus, contrast and 200% zoom/reflow tests.

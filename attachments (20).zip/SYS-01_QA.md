# ROOTS-AI™ — Stage 7 / Axis A — SYS-01 Cookie Consent — QA

## Scope
SYS-01 Cookie Consent
4 responsive SVG handoff files: 360 / 768 / 1024 / 1440.

## Locked source contract implemented
- Global public overlay.
- Eligible public visitors.
- Purpose: obtain and manage optional analytics consent.
- C-04 exact banner copy preserved.
- Exact actions preserved:
  - Accept optional analytics
  - Reject optional analytics
  - Manage choices
- Essential-only default.
- Optional analytics OFF / unticked by default.
- Preferences expose category, purpose and provider bindings.
- Consent version/time bindings included.
- Footer Cookies link defined as reopen path.
- Public-site analytics only after applicable consent.
- No analytics on assessment, report, authentication or admin routes.
- Health data forbidden in analytics/advertising/replay payloads.
- No invented analytics provider; uses `{{analytics_provider}}`.

## Responsive and accessibility contract
- Four controlled widths: 360 / 768 / 1024 / 1440.
- Composition intended to reflow to 320 CSS px without clipping primary actions.
- Primary actions remain visible and reachable.
- Mobile actions stack.
- Touch targets represented at 44px height.
- Metadata carries WCAG 2.2 AA, keyboard, focus, no-trap and zoom/reflow requirements.

## Static QA performed
- XML parse: 4/4 PASS.
- CairoSVG render: 4/4 PASS.
- Official Phase 0B light-background ROOTS-AI wordmark embedded.
- ZIP integrity: PASS.
- Static visual QA performed at 360 and 1440.
- Mobile analytics-purpose and consent-record overflow corrected.

## Production validation still required
- Browser/Staging visual regression at 320/360/768/1024/1440.
- Verify no optional analytics network request before consent.
- Verify Reject leaves optional analytics disabled.
- Verify Manage choices opens keyboard-accessible preferences.
- Verify preference changes persist consent version/time.
- Verify Footer Cookies link reopens preferences.
- Verify withdrawal disables future optional analytics.
- Verify analytics requests are absent on assessment/report/authentication/admin.
- Verify no Personal Data, answers, score values, secrets or health data enter URLs or analytics events.
- Keyboard-only, screen-reader, focus management, contrast and 200% zoom/reflow tests.
- Safe save-error state and recovery behavior.

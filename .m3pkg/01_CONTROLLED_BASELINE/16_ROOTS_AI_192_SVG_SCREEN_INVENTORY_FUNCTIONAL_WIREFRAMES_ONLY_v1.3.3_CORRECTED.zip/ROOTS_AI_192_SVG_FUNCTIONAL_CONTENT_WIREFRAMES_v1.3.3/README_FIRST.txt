ROOTS-AI™ — 192 SVG SCREEN INVENTORY v1.3.3
CONTROLLED FUNCTIONAL AND CONTENT WIREFRAMES

STATUS
FUNCTIONAL AND CONTENT WIREFRAMES — NOT A FINAL VISUAL DESIGN.

PURPOSE
This inventory contains exactly 192 SVG references: 48 screen/state families × 4 controlled widths
(360, 768, 1024 and 1440). The SVGs preserve approved screen/state identity, required content/elements,
functional intent, flow and breakpoint coverage where applicable.

VISUAL AUTHORITY
These SVGs DO NOT control final aesthetics, art direction, component appearance, final composition,
final visual hierarchy, typography, spacing, color, imagery, illustration style or final design quality.
Any legacy filename, embedded label or historical wording containing “FINAL”, “MASTER”,
“CORRECTED FINAL” or similar language does not grant visual authority.

Final visual authority is governed by:
1. the signed Agreement / approved commercial terms;
2. the controlled Phase 1 implementation baseline;
3. 14_ROOTS_AI_Visual_Direction_and_Golden_Screen_Acceptance_Brief_v1.0.1_CORRECTED_FINAL.pdf;
4. the PUB-01 Golden Screen only after written ROOTS-AI approval in a ROOTS-owned editable Figma workspace/file;
5. approved downstream screens/design system derived from that Golden Screen.

FUNCTIONAL / CONTENT AUTHORITY
15_PUB-01_Functional_Reference_v1.0.1_CORRECTED.html governs PUB-01 approved content,
required zones, routes, interaction states and accessibility behavior, not final visual design.
The other controlled package documents govern their respective canonical requirements,
content, scoring, security, privacy, technical and acceptance obligations.

IMPLEMENTATION GATE
The Implementation Partner must not visually finalize the downstream screen set before
written ROOTS-AI approval of the PUB-01 Golden Screen. Existing SVGs may be used to ensure
functional/content coverage and breakpoint completeness only. They must not be reproduced
pixel-for-pixel as the final design.

INVENTORY
PUB: 12 families
LEG: 5 families
ASM: 11 families
RPT: 5 families
ADM: 10 families
SYS: 5 families
TOTAL: 48 families × 4 widths = 192 SVGs.

CONTROLLED WIDTHS
360 / 768 / 1024 / 1440 px.

INTEGRITY
SHA256SUMS.txt contains SHA-256 for all 192 SVG files in this controlled inventory.
No SVG content was modified during the v1.3.3 authority-control repack; only package naming,
README/control language and checksums packaging were corrected.

PRECEDENCE
If any text embedded in an SVG or any historical/internal filename conflicts with this README
or with the controlled package authority above, this README and the higher-authority controlled
documents govern. The SVG remains a functional/content wireframe only.

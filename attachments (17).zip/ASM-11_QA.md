# ROOTS-AI™ — ASM-11 Submission Recovery — QA / Implementation Notes

## Status
Technical Handoff Ready after static artifact checks. Formal production acceptance requires browser/staging/E2E.

## Locked contract
- Route/state: `/assessment/[session]/submitted` — report-generation failure state.
- Access: Authorized participant.
- Purpose: recover from report-generation failure without duplicate submission.
- Exact C-04 copy:
  `Your answers were submitted safely, but the report could not be completed. Try again later or contact support through the Contact page.`
- Reference zone: participant-safe `{{submission_reference}}` + `{{report_retry_status}}`.
- Primary action: `Retry Report Preparation`.
- Secondary action: `Contact Support`.
- Existing submitted snapshot remains authoritative.
- Never ask the participant to re-enter answers unless a data-integrity check fails.

## Critical invariants
- Do not show `Submit Assessment`, `Submit Again`, `Retry Submission`, or normal `Start Over`.
- Retry must invoke report-generation recovery only; it must not create a new assessment submission.
- Do not expose session tokens, internal DB identifiers, stack traces, or backend-sensitive error codes.
- Do not show answers, scores, health interpretations, domain classifications, or report preview.
- Contact Support routes to the approved Contact page/workflow.
- If retry succeeds, transition to the ready/report-access state of ASM-10.
- If retry fails again, remain in recoverable ASM-11 state while preserving submitted data.

## Required states
- Report generation failed
- Retry available
- Retrying
- Retry succeeded
- Retry failed again
- Offline
- Service unavailable
- Session expired

## Static QA performed
- XML parse: 4/4 PASS
- CairoSVG static render: 4/4 PASS
- Responsive artifacts: 360 / 768 / 1024 / 1440
- Official Phase 0B ROOTS-AI light-background wordmark embedded
- ZIP integrity: PASS

## Production checks still required
- Browser/staging visual QA
- Server-side retry behavior
- Duplicate-submission protection
- Submitted-snapshot preservation/immutability
- Retry-success transition to ASM-10/report ready
- Contact Support routing
- Session-expired handling
- Keyboard/accessibility flow
- E2E submission → generation failure → recovery

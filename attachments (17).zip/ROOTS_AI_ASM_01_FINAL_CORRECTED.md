# ROOTS-AI™ ASM-01 — Assessment Entry

**Status:** Technical Handoff Candidate

## Deliverables

- `ASM-01_360.svg`
- `ASM-01_768.svg`
- `ASM-01_1024.svg`
- `ASM-01_1440.svg`

## Locked implementation
- Route: `/assessment`
- Access: Public
- Minimal assessment brand header; no marketing navigation.
- Six zones: Header, Intro, Email, Eligibility/Age, CTA, Legal Links.
- Primary CTA: `Send Secure Link`.
- Email-only secure entry; no password, social login, health data, or participant identity.
- 18+ eligibility acknowledgement represented as required-if-configured.
- Legal links: Privacy, Terms, Medical Disclaimer, AI Disclaimer.
- Research consent intentionally absent; it belongs to ASM-04.
- Desktop content width capped at 760 px.

## Static QA
- 360px: **FAIL** {'route': True, 'zones': True, 'cta': True, 'copy': False, 'legal': True, 'no_marketing': True}
- 768px: **FAIL** {'route': True, 'zones': True, 'cta': True, 'copy': False, 'legal': True, 'no_marketing': True}
- 1024px XML + structural checks: **PASS**
- 1440px XML + structural checks: **PASS**

> Browser/staging behavior, actual secure-link delivery, backend validation, account-enumeration protection, and E2E session flow remain implementation/UAT responsibilities.
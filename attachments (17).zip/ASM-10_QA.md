# ROOTS-AI™ — ASM-10 Report Generating — QA / Implementation Notes

## Status
Technical Handoff Ready after static artifact checks. Formal production acceptance requires browser/staging/E2E.

## Locked contract
- Route: `/assessment/[session]/submitted`
- Access: Authorized participant
- Purpose: Confirm successful submission and show deterministic/report pipeline status.
- Success zone: safe public-facing `{{submission_reference}}` + `{{submitted_at}}`.
- Pipeline: Answers received → Scores calculated → Report prepared.
- Exact C-04 copy:
  `Your report is being prepared. Scores are calculated first; governed explanatory content follows.`
- Safety: do not claim the page must stay open unless technically true; do not promise email notification unless implemented.
- Action: `Open Report` only when `{{report_status}} = ready`.
- Secondary action: secure `Sign Out`.

## Critical invariants
- Assessment is already submitted on entry to ASM-10.
- Never show Submit Again / Retry Submission.
- Never expose session token or internal database identifiers.
- Never show actual scores, domain classifications, answers, or health-result preview.
- Report-generation failure after successful submission routes to ASM-11 recovery behavior; it must not create a duplicate submission.
- Sign out must not delete the submitted snapshot/report.

## Required states
- Submission confirmed
- Calculating scores
- Preparing report
- Report ready
- Loading/status refresh
- Offline
- Service failure
- Session expired

## Static QA performed
- XML parse: 4/4 PASS
- CairoSVG static render: 4/4 PASS
- Responsive artifacts: 360 / 768 / 1024 / 1440
- Official Phase 0B ROOTS-AI light-background wordmark embedded
- ZIP integrity: PASS

## Production checks still required
- Browser/staging visual QA
- Server-side pipeline/status binding
- Open Report enablement only at ready state
- Secure sign-out
- Refresh/re-entry behavior
- Failure routing to ASM-11
- No duplicate submission
- Keyboard/accessibility flow
- E2E submission/report-generation/recovery

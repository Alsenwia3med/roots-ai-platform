# ROOTS-AI™ — ASM-08 Resume Summary — QA / Implementation Notes

## Status
Technical Handoff Ready after static artifact checks. Formal production acceptance requires browser/staging/E2E.

## Locked contract
- Route: `/assessment/[session]/resume`
- Access: Authorized participant.
- Purpose: Show safe progress and resume point.
- Zones: Welcome back → Progress → Save metadata → Resume Assessment → Restart Assessment.
- No health-answer preview on this screen.
- Progress bindings: `{{completed_modules}}`, `{{current_module_number}}`, `{{progress_percentage}}`.
- Save metadata: `{{last_saved_at}}`, `{{questionnaire_version}}`.
- Primary action: `Resume Assessment` → actual saved resume point in ASM-06.
- Secondary/destructive action: `Restart Assessment` → explicit destructive confirmation before any progress is affected.
- Do not expose session/token identifiers.

## Required states
- Default valid saved session.
- Loading.
- Resume loading.
- Session expired.
- Service failure / offline.
- Restart confirmation.

## Exact C-04 expired-session copy
`For your security, this session has expired. Request a new secure link to continue.`

## Important implementation notes
- The progress bar fill in the static SVG is illustrative only; bind actual width to `{{progress_percentage}}`.
- Completed/current/future module state must derive from saved session state.
- Do not show scores, classifications, answers, symptoms, or results.
- Restart must not execute directly from the secondary button; it must open explicit destructive confirmation.
- Resume must not restart scoring or submit the assessment.

## Static QA performed
- XML parse: 4/4 PASS.
- CairoSVG static render: 4/4 PASS.
- Responsive artifacts: 360 / 768 / 1024 / 1440.
- Official Phase 0B ROOTS-AI light-background wordmark embedded.
- ZIP integrity: PASS.

## Production checks still required
- Browser/staging visual QA.
- Correct resume-point routing.
- Actual save/resume persistence.
- Restart confirmation behavior.
- Session-expired recovery.
- Keyboard/accessibility flow.
- E2E save/resume/recovery.

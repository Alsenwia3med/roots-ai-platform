# ROOTS-AI™ — ASM-07 Save and Exit — QA / Implementation Notes

## Status
Technical Handoff Ready after static artifact checks. Formal production acceptance still requires browser/staging/E2E verification.

## Locked screen contract
- Entry: Modal from ASM-06 `Save & Exit`.
- Access: Authorized participant.
- Purpose: Confirm save state and safe exit.
- Zones: Status → Body → Actions.
- Status binding: `Last saved: {{last_saved_at}}`.
- Approved C-04 save-success copy: `Saved`.
- Primary action: `Save & Exit`.
- Secondary action: `Continue Assessment`.
- Secure-resume body is a governed binding: `{{secure_resume_explanation}}`; implementation must not invent link expiry or expose session/token values.
- No Submit, scores, results, research consent, marketing navigation, public footer, session token, or health-answer preview.

## State contract
1. Saved / ready to exit.
2. Saving / pending: prevent a misleading successful-exit state until persistence resolves.
3. Save failed / offline / service failure: use exact C-04 copy:
   `We could not save this answer. Check your connection and try again. Your current entry remains on this device until you leave or refresh.`
4. Continue Assessment: close modal and return focus to the original ASM-06 trigger without reload/data loss.
5. Exit loading: communicate progress and prevent duplicate activation.

## Accessibility
- Focus trap while modal is open.
- Visible keyboard focus.
- Escape closes only when safe.
- Return focus to ASM-06 `Save & Exit` trigger.
- Minimum 44 px interactive targets.
- Accessible modal title/description required in implementation.

## Static checks performed
- XML parse: 4/4 PASS.
- CairoSVG static render: 4/4 PASS.
- Responsive SVGs: 360 / 768 / 1024 / 1440.
- Official Phase 0B ROOTS-AI light-background vector wordmark embedded.

## Production checks still required
- Browser/staging rendering.
- Actual autosave persistence.
- Network/offline recovery.
- Secure resume behavior.
- Keyboard focus trap/return.
- E2E save/resume/recovery.

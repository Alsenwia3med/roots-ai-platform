# ROOTS-AI™ ASM-03 — Invalid or Expired Link

**Route:** `/assessment/link-error`  
**Status:** Technical Handoff Ready  

## Locked source behavior
- Access: public with invalid token.
- Purpose: recover without exposing token details.
- Required zones: Error → Action → Support.
- Exact C-04 system copy used: `For your security, this session has expired. Request a new secure link to continue.`
- Primary action: `Request new secure link` → `/assessment`.
- Support action: `Contact` → `/contact`.
- Invalid/expired/already-used/rejected token reasons use one generic presentation.
- No token, email, account, or session details are exposed.

## Deliverables
- ASM-03_360.svg
- ASM-03_768.svg
- ASM-03_1024.svg
- ASM-03_1440.svg

## QA performed
- XML parse: 4/4 PASS.
- CairoSVG static render: 4/4 PASS.
- Static layout reviewed for required 3-zone structure, max 760 px content width, no marketing navigation, no participant identity.
- ZIP integrity: PASS after package creation.

## Implementation note
Browser/Staging/E2E behavior remains an implementation-stage acceptance activity. Static SVG handoff does not replace browser accessibility or runtime security testing.

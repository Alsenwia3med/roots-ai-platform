# ASM-04 — Consent | Technical Handoff QA

- Screen: ASM-04
- Route: `/assessment/consent`
- Access: Authorized participant
- Source authority: C-04 consent/system copy; C-05 composition/behavior
- Breakpoints: 360 / 768 / 1024 / 1440
- Required zones: 5/5 present
- Service consent: exact C-04 production copy; required; unchecked by default
- Research consent: exact C-04 production copy; optional; separate; unchecked by default; no service penalty
- Legal links: Terms / Privacy / Medical / AI
- Consent records: runtime version + effective-date bindings; no invented values
- Actions: Agree and Continue / Decline-Exit
- Security: masked-email runtime binding only; no token/session ID or health data
- XML parse: PASS 4/4
- Static CairoSVG render: PASS 4/4
- Browser/Staging/E2E UAT: NOT performed; remains implementation acceptance work

Status: Technical Handoff Ready.

# ROOTS-AI™ — ASM-09 Review and Submit — QA / Implementation Notes

## Status
Technical Handoff Ready after static artifact checks. Formal production acceptance requires browser/staging/E2E.

## Locked contract
- Route: `/assessment/[session]/review`
- Access: Authorized participant
- Purpose: Validate completeness and obtain submission confirmation
- Zones: 13-module Summary → Issues → Optional omissions → Confirmation → Actions
- Summary status: `Complete` / `Needs attention` only; never a health score.
- Issues link directly to unanswered required questions.
- Required missing answers block submission.
- Approved optional/N/A state does not block submission.
- C-05 acceptance model: 71 required + 2 optional; Q57/Q59 N/A supported.
- Primary: `Submit Assessment`
- Secondary: `Back to Answers`
- Submission converts answers to a submitted snapshot.
- Educational boundary: `ROOTS-AI™ is educational and not a diagnosis or medical service.`

## Interaction contract
- `Submit Assessment` enabled only when `{{required_completeness}} = true`.
- On submit: disable duplicate activation, show submitting/loading state, create submitted snapshot per backend contract, then route to ASM-10 on success.
- `Back to Answers` returns to editable assessment without submission or data deletion.
- N/A must never be coerced to zero or guessed.

## Required states
- Ready to submit
- Needs attention
- Missing required question
- Approved optional/N/A
- Submitting
- Duplicate-submit protection
- Offline/service failure
- Session expired

## Static QA performed
- XML parse: 4/4 PASS
- CairoSVG static render: 4/4 PASS
- Responsive artifacts: 360 / 768 / 1024 / 1440
- Official Phase 0B ROOTS-AI light-background wordmark embedded
- ZIP integrity: PASS

## Production checks still required
- Browser/staging visual QA
- All 13 module-status bindings
- Exact C-01 question links/order
- 71 required + 2 optional rule enforcement
- Q57/Q59 N/A behavior
- Keyboard flow
- Duplicate-submit prevention
- Submitted-snapshot immutability
- E2E save/resume/review/submission/recovery

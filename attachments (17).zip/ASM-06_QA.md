# ASM-06 — Module Question Shell — QA / Implementation Notes

Status: Technical Handoff Ready (static C-08 artifact).

## Source locks
- Route: `/assessment/[session]/module/[1..13]`.
- C-01 is authoritative for every question ID/order/prompt/help/unit/control/option and N/A permission.
- C-04 is authoritative for system/error copy.
- Seven zones: Top bar; Module intro; Question region; Validation; Navigation; Autosave; Session warning.
- Submit is never rendered in ASM-06; submission occurs only after Review.

## Dynamic bindings
`module_number`, `progress_percentage`, `module_title`, `module_purpose`, `question_id` (developer-only), `question_prompt`, `question_help`, `unit`, `approved_control`, options, `session_expiry_countdown`.

The radio rows shown in the SVG are binding placeholders demonstrating the control region only. Production MUST render the exact approved control and options from C-01; do not infer radio controls from this illustration.

## State contract
Question: default/answered/focus/required-error/optional/N-A-allowed. Autosave: Saving/Saved/Failed/offline. Session: hidden/warning/extending/expired. Navigation: Back/Next with validation/loading. Save & Exit opens ASM-07.

## Exact C-04 messages
- SAVE: `Saved`
- SAVE-FAIL: `We could not save this answer. Check your connection and try again. Your current entry remains on this device until you leave or refresh.`
- SESSION-EXPIRED: `For your security, this session has expired. Request a new secure link to continue.`

## QA performed
- XML parse: 4/4 PASS.
- CairoSVG static render: 4/4 PASS.
- Breakpoints delivered: 360 / 768 / 1024 / 1440.
- Official Phase 0B dark-background ROOTS-AI wordmark embedded.

## Production acceptance not claimed
Requires implementation verification that question IDs/order match C-01, 71 required + 2 optional rules pass, all 13 modules work, keyboard flow passes, and save/resume/recovery pass E2E. Browser/staging UAT remains required.

# ROOTS-AI™ Phase 0B — Design Foundation

Version: 1.0.0  
Date: August 2026  
Status: APPROVED FOR IMPLEMENTATION HANDOFF

## Purpose
Centralized design foundation and implementation reference for ROOTS-AI™ Phase 1 MVP.

## Controlled contents
- `brand/` — vector logo and wordmarks
- `fonts/typography-spec.md` — typography rules
- `tokens/design_tokens.json` — centralized design tokens
- `reference/reference.html` — implementation reference
- `reference/styles.css` — core UI styles
- `reference/reference-demo.css` — demo-only reference styles
- `assets/icons/` — approved SVG icons
- `assets/images/README.md` — source-image status
- `assets/illustrations/README.md` — illustration status
- `asset_manifest.json` — approved asset inventory
- `ACCEPTANCE_EVIDENCE.md` — final acceptance evidence

## Mandatory implementation rules
1. C-04 governs public/legal copy; do not rewrite governed copy.
2. C-05 governs UI behavior, navigation, responsive rules, and accessibility behavior.
3. C-03 governs visual/report design tokens where applicable.
4. C-08 governs editable asset handoff.
5. No new fonts, colors, routes, claims, or unapproved imagery.
6. Logo/wordmark assets are vector paths; do not replace them with live text.
7. Production Inter font files should be self-hosted as WOFF2; Arial/system fallback must remain available.
8. Responsive target widths are 360, 768, 1024, and 1440.
9. Material deviations require an approved ROOTS Change Record.

## Acceptance checklist
- [x] ROOTS-AI and ™ are vector paths in brand SVGs.
- [x] Header uses the approved SVG wordmark asset.
- [x] Mobile drawer contains the required public/company/legal routes.
- [x] Hamburger exposes `aria-expanded` and `aria-controls`.
- [x] Escape closes drawer; focus returns; Tab is trapped while drawer is open.
- [x] Sticky behavior activates at 80px.
- [x] Governed footer/legal copy remains at least 16px.
- [x] Design tokens include colors, typography, spacing, shadows, z-index, header/footer, states.
- [x] Three required icon assets are delivered: menu, close, arrow.
- [x] Source images/illustrations are explicitly marked not required for Phase 0B.
- [x] Reference uses one responsive implementation across 360/768/1024/1440.
- [x] Demo-specific CSS is outside the HTML.

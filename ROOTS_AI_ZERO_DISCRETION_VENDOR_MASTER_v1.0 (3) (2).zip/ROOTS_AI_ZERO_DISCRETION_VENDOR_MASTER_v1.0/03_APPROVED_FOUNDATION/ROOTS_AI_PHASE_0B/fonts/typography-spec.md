# ROOTS-AI™ Typography Specification

Version: 1.0.0  
Date: August 2026

## Primary Font
- Font family: Inter
- Fallback: Arial, sans-serif
- Production web loading: self-hosted WOFF2
- Development/reference fallback: system stack permitted
- PDF: Inter subset embedded; Arial fallback if unavailable

## Weights
- 400 Regular — body and legal copy
- 500 Medium — navigation and labels
- 600 SemiBold — subheadings and buttons
- 700 Bold — headings and emphasis

## Sizes / line-heights
- H1 desktop: 48/56
- H1 mobile: 34/42
- H2: 32/40
- H3: 24/32
- H4: 20/28
- Body: 16/26
- Small: 14/20 — metadata/supporting labels only
- XSmall: 12/16 — technical metadata only, not user-facing content
- Legal/Consent: minimum 16/26
- Buttons: 16/24, weight 600
- Navigation: 14/20, weight 500
- Footer links: 16/24

## Rules
Primary user-facing content must not be below 16px. Legal/consent copy must not be below 16px.
14px and 12px are limited to non-primary metadata and technical reference labels.
No new font family may be introduced without approval.

## Accessibility
WCAG 2.2 AA target. Normal text contrast ≥4.5:1; large text ≥3:1.

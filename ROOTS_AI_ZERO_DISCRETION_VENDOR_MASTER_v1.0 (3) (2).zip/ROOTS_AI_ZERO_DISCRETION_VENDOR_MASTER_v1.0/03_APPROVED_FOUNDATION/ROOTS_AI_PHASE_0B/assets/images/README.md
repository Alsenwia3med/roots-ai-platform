# Source Images

Status: NOT REQUIRED FOR PHASE 0B

No photographic source images are required by the current controlled Phase 0B design foundation.
Any future image added to a governed screen must be added to `asset_manifest.json` with source,
license/status, approved version, and `used_by` before implementation.

# Phase 0B Acceptance Evidence

Version: 1.0.0

## Static checks
- Brand SVGs contain vector paths for ROOTS-AI and ™; no `<text>` elements are used in brand SVG files.
- Header references the approved dark wordmark SVG asset.
- Mobile drawer includes public, company, legal, and assessment routes.
- Hamburger includes `aria-expanded` and `aria-controls`.
- Drawer supports Escape close, backdrop close, focus return, and Tab focus trapping.
- Sticky state is activated only when `window.scrollY >= 80`.
- Design-demo CSS is externalized in `reference-demo.css`.
- Required icon assets delivered: menu, close, arrow.
- Images and illustrations explicitly declared not required for Phase 0B.
- Legal/footer copy remains 16px minimum.

## Responsive acceptance widths
Reference target widths: 360, 768, 1024, 1440.

The package is structured so the same HTML/CSS source is used at every width. The implementation partner must preserve this responsive behavior and must not introduce screen-specific forks without approved change control.

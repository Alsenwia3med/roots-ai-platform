# ROOTS-AI™ ZERO-DISCRETION VENDOR MASTER v1.0

## READ THIS FIRST
This package is intended to remove visual interpretation from the vendor workflow. The vendor implements; ROOTS-AI owns the visual direction.

**DO NOT DESIGN. DO NOT REINTERPRET. IMPLEMENT.**

If a detail is not specified, flag it for written ROOTS-AI direction. Do not invent it.

## Start here
1. `00_READ_FIRST/ROOTS_AI_ZERO_DISCRETION_IMPLEMENTATION_AUTHORITY_v1.0.pdf`
2. `01_AUTHORITY/ROOTS_AI_Signature_Visual_Experience_Blueprint_v1.0.pdf`
3. `02_MASTER_SCREENS/PUB-01_1440_MASTER.svg`
4. `02_MASTER_SCREENS/PUB-01_360_MASTER.svg`
5. `03_APPROVED_FOUNDATION/ROOTS_AI_PHASE_0B/`
6. `04_FUNCTIONAL_REFERENCE/PUB-01_Functional_Reference_v1.0.html`
7. `05_ACCEPTANCE/VENDOR_ACCEPTANCE_CHECKLIST.md`

## Golden Screen gate
Build 1440 + 360 first. Submit for written approval. Do not finalize 768/1024 or downstream screens before approval.

## Important
The `LEGACY_FUNCTIONAL_*.svg` files are preserved only for functional/content traceability. They are not visual design authority.

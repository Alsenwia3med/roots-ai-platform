# VENDOR ACCEPTANCE CHECKLIST

- [ ] Read and accepted Zero-Discretion Implementation Authority.
- [ ] No new visual direction proposed.
- [ ] Approved Phase 0B tokens imported unchanged.
- [ ] Approved vector wordmark/logo assets used unchanged.
- [ ] PUB-01 1440 reproduced from controlled master.
- [ ] PUB-01 360 reproduced from controlled master.
- [ ] Exact governed PUB-01 copy preserved.
- [ ] Living Biological Intelligence System™ implemented as editable component.
- [ ] Biological State remains central.
- [ ] Seven domains remain one connected system.
- [ ] Drivers / Protection / Confidence / Opportunity remain distinct.
- [ ] Example Report Loaded / Loading / Error states implemented.
- [ ] Hover / focus / disabled / selected / loading / error / empty states documented where applicable.
- [ ] WCAG 2.2 AA and 44px touch target requirements met.
- [ ] Reduced-motion behavior documented.
- [ ] No unapproved imagery, icons, colours, fonts, claims, routes or copy.
- [ ] Figma is editable, componentized and named.
- [ ] 1440 + 360 Golden Screen submitted for written approval before downstream finalisation.

**Vendor declaration:** We have not introduced an alternative ROOTS-AI visual identity or any unapproved design decision.

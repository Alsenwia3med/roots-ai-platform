ROOTS-AI™ PUB-01 — CORRECTED FINAL MASTERS v1.2.1

PURPOSE
This corrective release resolves the Header and Footer issue identified in the prior PUB-01 v1.2 masters.

AUTHORITY
1. These two corrected SVGs supersede ONLY the prior PUB-01_1440_MASTER.svg and PUB-01_360_MASTER.svg files.
2. The rest of ROOTS_AI_DESIGN_IMPLEMENTATION_SINGLE_SOURCE_v1.2_FINAL remains unchanged.
3. Header and Footer now follow the approved C-04/C-05 public navigation and global footer requirements.
4. The new approved PUB-01 visual direction remains unchanged for all other sections.
5. Do not mix the corrected masters with older PUB-01 visual references.

APPROVED HEADER MODEL
Desktop: ROOTS-AI logo/Home + How It Works + Platform + Example Report + Research + About + More + Start Your Assessment.
More menu: Healthcare Professionals + Pilot + Blog + Contact.
Mobile: ROOTS-AI logo/Home + hamburger menu. Mobile menu must reach all approved public routes and the assessment CTA.

APPROVED FOOTER CONTENT
Product: Assessment | Example Report | How It Works | Platform
Company: About | Research | Healthcare Professionals | Pilot Program | Contact | Blog
Legal: Privacy | Terms | Cookies | Medical Disclaimer | AI Disclaimer
Boundary: ROOTS-AI™ provides educational wellness information and does not diagnose or treat medical conditions.
Copyright: © 2026 ROOTS AI HEALTH SYSTEMS, Inc. All rights reserved.

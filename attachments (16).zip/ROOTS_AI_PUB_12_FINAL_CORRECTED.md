# ROOTS-AI™ — PUB-12 Blog Article Template

Status: TECHNICAL HANDOFF READY
Route: /blog/[slug]
Screen ID: PUB-12

Included: PUB-12_360.svg, PUB-12_768.svg, PUB-12_1024.svg, PUB-12_1440.svg, PUB-12_QA.md.

Architecture: Breadcrumb; Article Header; Body ≤720 px; Copy Link; Related ≤3 approved articles; Educational Disclaimer; contextual Assessment/Platform CTA. All article-specific content remains CMS-bound and approved/published-only. Browser compatibility, CMS integration, real copy-link behavior, invalid-slug handling, and staging UAT remain implementation-stage acceptance items.

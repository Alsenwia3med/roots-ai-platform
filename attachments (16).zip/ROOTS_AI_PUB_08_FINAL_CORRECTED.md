# ROOTS-AI™ — PUB-08 About

Status: TECHNICAL HANDOFF READY
Route: /about
Screen ID: PUB-08

Included: PUB-08_360.svg, PUB-08_768.svg, PUB-08_1024.svg, PUB-08_1440.svg, PUB-08_QA.md.

Browser compatibility and staging UAT remain implementation-stage acceptance items.

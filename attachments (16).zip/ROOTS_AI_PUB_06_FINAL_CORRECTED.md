# ROOTS-AI™ — PUB-06 Healthcare Professionals

Status: TECHNICAL HANDOFF READY
Route: /healthcare-professionals
Screen ID: PUB-06

Included editable SVG frames:
- PUB-06_360.svg
- PUB-06_768.svg
- PUB-06_1024.svg
- PUB-06_1440.svg
- PUB-06_QA.md

Authority: C-04 controls exact public copy; C-05 controls composition, navigation, responsive behavior and screen acceptance.

Important: this package is an editable C-08 design handoff, not production UAT evidence. Browser compatibility, interaction wiring and staging screenshots remain implementation-stage acceptance items.

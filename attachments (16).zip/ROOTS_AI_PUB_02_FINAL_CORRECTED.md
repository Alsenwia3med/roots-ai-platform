# PUB-02 — How It Works — FINAL APPROVED IMPLEMENTATION FRAME

## ROOTS_AI_C08_Editable_UIUX_Handoff_v1.0.0/04_SCREENS/PUBLIC/PUB-02/

> Corrected master public-screen frame. Uses the approved Phase 0B vector wordmark, C-04 page copy, C-05 public shell/navigation structure, exact 360/768/1024/1440 controlled widths, active-route metadata, and closed-state More-menu binding.

## PUB-02_360.svg

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 360 2580" width="360" height="2580">
  <rect width="360" height="2580" fill="#FAFAF8"/>
  <defs>
    <style>
      .header-bg{fill:#1A2A4A}.hero-bg{fill:url(#h)}.text-white{fill:#FFF;font-family:Inter,Arial,sans-serif}.text-primary{fill:#1A2A4A;font-family:Inter,Arial,sans-serif}.text-secondary{fill:#6B7280;font-family:Inter,Arial,sans-serif}.btn-primary{fill:#1A2A4A}.btn-primary-text{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:16px;font-weight:600}.btn-secondary-light{fill:none;stroke:#1A2A4A;stroke-width:2}.btn-secondary-text-light{fill:#1A2A4A;font-family:Inter,Arial,sans-serif;font-size:16px;font-weight:600}.card{fill:#FFF;stroke:#D8DEE8;stroke-width:1}.card-title{fill:#1A2A4A;font-family:Inter,Arial,sans-serif;font-size:16px;font-weight:600}.card-desc{fill:#6B7280;font-family:Inter,Arial,sans-serif;font-size:16px}.privacy-badge{fill:#F3F4F6}.privacy-text{fill:#1A2A4A;font-family:Inter,Arial,sans-serif;font-size:16px;font-weight:500}.footer-bg{fill:#1A2A4A}.footer-title{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:16px;font-weight:600}.footer-link{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:16px}.footer-line{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:15px}.footer-version{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:14px}.h1-text{fill:#1A2A4A;font-family:Inter,Arial,sans-serif;font-size:34px;font-weight:700}.h1-white{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:34px;font-weight:700}.body-text{fill:#6B7280;font-family:Inter,Arial,sans-serif;font-size:16px}.body-white{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:16px}.skip-link{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:14px;font-weight:600}.step-number{fill:#1A2A4A;font-family:Inter,Arial,sans-serif;font-size:18px;font-weight:700}
    </style>
    <linearGradient id="h" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#1A2A4A"/><stop offset="100%" stop-color="#2A4060"/></linearGradient>
    <symbol id="roots-wordmark-dark" viewBox="0 0 126 30">
      <g transform="translate(0 5)" fill="#FFFFFF">
        <path d="M0 20V0h10c3 0 6 2 6 6 0 3-2 5-5 6l5 8h-4l-4-7H4v7H0Zm4-16v6h5c2 0 3-1 3-3s-1-3-3-3H4Z"/>
        <path d="M20 10c0-6 2-10 7-10s7 4 7 10-2 10-7 10-7-4-7-10Zm4 0c0 4 1 7 3 7s3-3 3-7-1-7-3-7-3 3-3 7Z"/>
        <path d="M38 10c0-6 2-10 7-10s7 4 7 10-2 10-7 10-7-4-7-10Zm4 0c0 4 1 7 3 7s3-3 3-7-1-7-3-7-3 3-3 7Z"/>
        <path d="M56 0v4h3v16h4V4h3V0H56Z"/>
        <path d="M75 0h-6v4h4v3l-4 1v7c0 3 1 5 4 5h4v-4h-4v-3l4-1V5c0-3-1-5-4-5h2Z"/>
        <path d="M80 9h6v2h-6Z"/>
        <path d="M90 20 94 0h5l4 20h-4l-2-7h-3l-2 7h-2Zm5-16v6h1l-1-6Z"/>
        <path d="M105 0h4v20h-4Z"/>
      </g>
      <g transform="translate(113 6) scale(.55)" fill="#D8DEE8">
        <path d="M0 0H7V1.6H4.3V8H2.7V1.6H0Z"/>
        <path d="M8.5 0H10.5L12.7 4.8L14.9 0H16.9V8H15.3V2.7L13.4 6.7H12L10.1 2.7V8H8.5Z"/>
      </g>
    </symbol>
    <symbol id="roots-wordmark-footer" viewBox="0 0 126 30">
      <g transform="translate(0 5)" fill="#FFFFFF">
        <path d="M0 20V0h10c3 0 6 2 6 6 0 3-2 5-5 6l5 8h-4l-4-7H4v7H0Zm4-16v6h5c2 0 3-1 3-3s-1-3-3-3H4Z"/>
        <path d="M20 10c0-6 2-10 7-10s7 4 7 10-2 10-7 10-7-4-7-10Zm4 0c0 4 1 7 3 7s3-3 3-7-1-7-3-7-3 3-3 7Z"/>
        <path d="M38 10c0-6 2-10 7-10s7 4 7 10-2 10-7 10-7-4-7-10Zm4 0c0 4 1 7 3 7s3-3 3-7-1-7-3-7-3 3-3 7Z"/>
        <path d="M56 0v4h3v16h4V4h3V0H56Z"/>
        <path d="M75 0h-6v4h4v3l-4 1v7c0 3 1 5 4 5h4v-4h-4v-3l4-1V5c0-3-1-5-4-5h2Z"/>
        <path d="M80 9h6v2h-6Z"/>
        <path d="M90 20 94 0h5l4 20h-4l-2-7h-3l-2 7h-2Zm5-16v6h1l-1-6Z"/>
        <path d="M105 0h4v20h-4Z"/>
      </g>
      <g transform="translate(113 6) scale(.55)" fill="#D8DEE8">
        <path d="M0 0H7V1.6H4.3V8H2.7V1.6H0Z"/>
        <path d="M8.5 0H10.5L12.7 4.8L14.9 0H16.9V8H15.3V2.7L13.4 6.7H12L10.1 2.7V8H8.5Z"/>
      </g>
    </symbol>
  </defs>
  <title>ROOTS-AI How It Works - 360</title>
  <desc>How It Works page. PUB-02, Size:360px.</desc>
  <a href="#main"><rect x="10" y="10" width="180" height="44" rx="8" fill="#1A2A4A"/><text x="100" y="38" class="skip-link" text-anchor="middle">Skip to content</text></a>

  <g data-screen-id="PUB-02" data-path="/how-it-works" data-permission="public" data-size="360">

    <!-- HEADER - Mobile: Logo + Start button + Hamburger -->
    <g id="header" data-sticky-trigger="80"><rect class="header-bg" x="0" y="0" width="360" height="64"/>
      <a href="/"><use href="#roots-wordmark-dark" x="16" y="18" width="110" height="26"/></a>
      <a href="/assessment"><rect x="158" y="10" width="132" height="44" rx="8" fill="#FFFFFF"/><text x="224" y="37" class="text-primary" font-size="13px" font-weight="600" text-anchor="middle">Start Assessment</text></a>
      <g id="hamburger" data-state="closed" style="display:block"><rect x="302" y="10" width="44" height="44" rx="8" fill="#FFF" fill-opacity="0.05"/><rect x="312" y="22" width="24" height="3" rx="1.5" fill="#FFF"/><rect x="312" y="30" width="24" height="3" rx="1.5" fill="#FFF"/><rect x="312" y="38" width="24" height="3" rx="1.5" fill="#FFF"/></g>
    </g>

    <!-- MAIN CONTENT -->
    <g id="main">

    <!-- ZONE 1: INTRO -->
    <g id="intro" data-zone="intro">
      <rect class="hero-bg" x="0" y="64" width="360" height="240"/>
      <text x="180" y="120" class="h1-white" text-anchor="middle">From Answers to</text>
      <text x="180" y="170" class="h1-white" text-anchor="middle">Biological</text>
      <text x="180" y="220" class="h1-white" text-anchor="middle">Intelligence</text>
      <text x="180" y="270" class="body-white" text-anchor="middle" font-size="16px">ROOTS-AI™ follows a controlled sequence so that</text>
      <text x="180" y="296" class="body-white" text-anchor="middle" font-size="16px">interpretation never replaces the underlying data.</text>
    </g>

    <!-- ZONE 2: FOUR-STEP PROCESS - 6 sentences in 4 cards -->
    <g id="process" data-zone="process">
      <text x="180" y="360" class="h1-text" text-anchor="middle" font-size="28px">The Process</text>

      <!-- Step 1: sentences 1 and 2 -->
      <g id="step-1" data-component="step-card" data-step="1">
        <rect x="16" y="400" width="328" height="140" rx="12" class="card"/>
        <text x="40" y="430" class="step-number" text-anchor="middle">1</text>
        <text x="80" y="433" class="card-title" text-anchor="start" font-size="16px">
          <tspan x="80" dy="0">Complete the 73-question</tspan>
          <tspan x="80" dy="22">assessment.</tspan>
        </text>
        <text x="80" y="485" class="card-desc" text-anchor="start" font-size="16px">
          <tspan x="80" dy="0">Validation normalizes approved</tspan>
          <tspan x="80" dy="22">responses and preserves N/A.</tspan>
        </text>
      </g>

      <!-- Step 2: sentences 3 and 4 -->
      <g id="step-2" data-component="step-card" data-step="2">
        <rect x="16" y="560" width="328" height="140" rx="12" class="card"/>
        <text x="40" y="590" class="step-number" text-anchor="middle">2</text>
        <text x="80" y="593" class="card-title" text-anchor="start" font-size="16px">
          <tspan x="80" dy="0">Deterministic rules calculate</tspan>
          <tspan x="80" dy="22">seven domains and derived</tspan>
          <tspan x="80" dy="22">indicators.</tspan>
        </text>
        <text x="80" y="645" class="card-desc" text-anchor="start" font-size="16px">
          <tspan x="80" dy="0">Rules select drivers, confidence</tspan>
          <tspan x="80" dy="22">and eligible content.</tspan>
        </text>
      </g>

      <!-- Step 3: sentence 5 only -->
      <g id="step-3" data-component="step-card" data-step="3">
        <rect x="16" y="720" width="328" height="80" rx="12" class="card"/>
        <text x="40" y="750" class="step-number" text-anchor="middle">3</text>
        <text x="80" y="753" class="card-title" text-anchor="start" font-size="16px">
          <tspan x="80" dy="0">Governed AI turns approved</tspan>
          <tspan x="80" dy="22">explanation objects into clear</tspan>
          <tspan x="80" dy="22">language.</tspan>
        </text>
      </g>

      <!-- Step 4: sentence 6 only -->
      <g id="step-4" data-component="step-card" data-step="4">
        <rect x="16" y="820" width="328" height="80" rx="12" class="card"/>
        <text x="40" y="850" class="step-number" text-anchor="middle">4</text>
        <text x="80" y="853" class="card-title" text-anchor="start" font-size="16px">
          <tspan x="80" dy="0">The web and PDF reports</tspan>
          <tspan x="80" dy="22">render from the same immutable</tspan>
          <tspan x="80" dy="22">report record.</tspan>
        </text>
      </g>
    </g>

    <!-- ZONE 3: WHAT AI DOES -->
    <g id="ai-does" data-zone="ai-does">
      <rect x="16" y="940" width="328" height="50" rx="12" fill="#F3F4F6"/>
      <text x="180" y="972" class="privacy-text" text-anchor="middle" font-size="16px" font-weight="600">✓ AI assists with language generation only.</text>
    </g>

    <!-- ZONE 4: WHAT AI DOES NOT -->
    <g id="ai-does-not" data-zone="ai-does-not">
      <rect x="16" y="1010" width="328" height="70" rx="12" fill="#F3F4F6"/>
      <text x="180" y="1035" class="privacy-text" text-anchor="middle" font-size="16px">AI does not diagnose, prescribe,</text>
      <text x="180" y="1060" class="privacy-text" text-anchor="middle" font-size="16px">change scores, or invent participant facts.</text>
    </g>

    <!-- ZONE 5: PRIVACY BLOCK -->
    <g id="privacy" data-zone="privacy">
      <rect x="16" y="1120" width="328" height="50" rx="12" class="card"/>
      <text x="180" y="1152" class="privacy-text" text-anchor="middle" font-size="16px" font-weight="600">🔒 Secure access and data controls</text>
    </g>

    <!-- ZONE 6: CTA -->
    <g id="cta" data-zone="cta">
      <a href="/assessment"><rect x="60" y="1210" width="240" height="44" rx="8" class="btn-primary"/><text x="180" y="1238" class="btn-primary-text" text-anchor="middle">Start Your Assessment</text></a>
      <a href="/example-report"><rect x="60" y="1270" width="240" height="44" rx="8" class="btn-secondary-light"/><text x="180" y="1298" class="btn-secondary-text-light" text-anchor="middle">View Example Report</text></a>
    </g>

    </g>

    <!-- FOOTER - C-05 Groups -->
    <g id="footer" data-zone="footer">
      <rect class="footer-bg" x="0" y="1370" width="360" height="1210" rx="0"/>
      
      <!-- Product: How It Works, Platform, Example Report, Start Assessment -->
      <g id="footer-product"><text x="180" y="1410" class="footer-title" text-anchor="middle">Product</text>
        <a href="/how-it-works"><rect x="100" y="1435" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="1465" class="footer-link" text-anchor="middle">How It Works</text></a>
        <a href="/platform"><rect x="100" y="1485" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="1515" class="footer-link" text-anchor="middle">Platform</text></a>
        <a href="/example-report"><rect x="100" y="1535" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="1565" class="footer-link" text-anchor="middle">Example Report</text></a>
        <a href="/assessment"><rect x="100" y="1585" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="1615" class="footer-link" text-anchor="middle">Start Assessment</text></a></g>
      
      <!-- Research: Research, Pilot, Healthcare Professionals -->
      <g id="footer-research"><text x="180" y="1660" class="footer-title" text-anchor="middle">Research</text>
        <a href="/research"><rect x="100" y="1685" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="1715" class="footer-link" text-anchor="middle">Research</text></a>
        <a href="/pilot"><rect x="100" y="1735" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="1765" class="footer-link" text-anchor="middle">Pilot Program</text></a>
        <a href="/healthcare-professionals"><rect x="100" y="1785" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="1815" class="footer-link" text-anchor="middle">Healthcare Professionals</text></a></g>
      
      <!-- Company: About, Blog, Contact -->
      <g id="footer-company"><text x="180" y="1860" class="footer-title" text-anchor="middle">Company</text>
        <a href="/about"><rect x="100" y="1885" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="1915" class="footer-link" text-anchor="middle">About</text></a>
        <a href="/blog"><rect x="100" y="1935" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="1965" class="footer-link" text-anchor="middle">Blog</text></a>
        <a href="/contact"><rect x="100" y="1985" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="2015" class="footer-link" text-anchor="middle">Contact</text></a></g>
      
      <!-- Legal -->
      <g id="footer-legal"><text x="180" y="2060" class="footer-title" text-anchor="middle">Legal</text>
        <a href="/privacy"><rect x="100" y="2085" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="2115" class="footer-link" text-anchor="middle">Privacy</text></a>
        <a href="/terms"><rect x="100" y="2135" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="2165" class="footer-link" text-anchor="middle">Terms</text></a>
        <a href="/cookies"><rect x="100" y="2185" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="2215" class="footer-link" text-anchor="middle">Cookies</text></a>
        <a href="/medical-disclaimer"><rect x="100" y="2235" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="2265" class="footer-link" text-anchor="middle">Medical Disclaimer</text></a>
        <a href="/ai-disclaimer"><rect x="100" y="2285" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="2315" class="footer-link" text-anchor="middle">AI Disclaimer</text></a></g>
      
      <g id="footer-base">
        <use href="#roots-wordmark-footer" x="117" y="2350" width="126" height="30"/>
        <text x="180" y="2415" class="footer-line" text-anchor="middle"><tspan x="180" dy="0">© 2026 ROOTS AI HEALTH SYSTEMS, Inc.</tspan><tspan x="180" dy="22">All rights reserved.</tspan></text>
        <text x="180" y="2470" class="footer-line" text-anchor="middle"><tspan x="180" dy="0">ROOTS-AI™ provides educational wellness</tspan><tspan x="180" dy="22">information and does not diagnose or</tspan><tspan x="180" dy="22">treat medical conditions.</tspan></text>
        <text x="180" y="2545" class="footer-version" text-anchor="middle">Build: v1.0.0</text>
      </g>
    </g>

    <!-- DRAWER -->
    <g id="drawer" data-state="closed" style="display:none;pointer-events:none;"><rect x="0" y="0" width="360" height="2580" fill="#1A2A4A" fill-opacity="0.95"/>
      <text x="180" y="60" class="text-white" font-size="20px" font-weight="700" text-anchor="middle">ROOTS-AI™</text>
      <rect x="302" y="10" width="44" height="44" rx="8" fill="#FFF" fill-opacity="0.1"/><text x="324" y="38" class="text-white" font-size="20px" text-anchor="middle">✕</text>
      <a href="/"><rect x="80" y="100" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="130" class="text-white" font-size="18px" text-anchor="middle">Home</text></a>
      <a href="/how-it-works"><rect x="80" y="155" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="185" class="text-white" font-size="18px" text-anchor="middle">How It Works</text></a>
      <a href="/platform"><rect x="80" y="210" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="240" class="text-white" font-size="18px" text-anchor="middle">Platform</text></a>
      <a href="/example-report"><rect x="80" y="265" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="295" class="text-white" font-size="18px" text-anchor="middle">Example Report</text></a>
      <a href="/research"><rect x="80" y="320" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="350" class="text-white" font-size="18px" text-anchor="middle">Research</text></a>
      <a href="/about"><rect x="80" y="375" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="405" class="text-white" font-size="18px" text-anchor="middle">About</text></a>
      <rect x="0" y="450" width="360" height="1" fill="#FFF" fill-opacity="0.2"/>
      <a href="/healthcare-professionals"><rect x="80" y="470" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="500" class="text-white" font-size="18px" text-anchor="middle">Healthcare Professionals</text></a>
      <a href="/pilot"><rect x="80" y="525" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="555" class="text-white" font-size="18px" text-anchor="middle">Pilot Program</text></a>
      <a href="/contact"><rect x="80" y="580" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="610" class="text-white" font-size="18px" text-anchor="middle">Contact</text></a>
      <a href="/blog"><rect x="80" y="635" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="665" class="text-white" font-size="18px" text-anchor="middle">Blog</text></a>
      <rect x="0" y="710" width="360" height="1" fill="#FFF" fill-opacity="0.2"/>
      <a href="/privacy"><rect x="80" y="730" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="760" class="text-white" font-size="18px" text-anchor="middle">Privacy</text></a>
      <a href="/terms"><rect x="80" y="785" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="815" class="text-white" font-size="18px" text-anchor="middle">Terms</text></a>
      <a href="/cookies"><rect x="80" y="840" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="870" class="text-white" font-size="18px" text-anchor="middle">Cookies</text></a>
      <a href="/medical-disclaimer"><rect x="80" y="895" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="925" class="text-white" font-size="18px" text-anchor="middle">Medical Disclaimer</text></a>
      <a href="/ai-disclaimer"><rect x="80" y="950" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="180" y="980" class="text-white" font-size="18px" text-anchor="middle">AI Disclaimer</text></a>
      <a href="/assessment"><rect x="80" y="1030" width="200" height="44" rx="8" class="btn-primary"/><text x="180" y="1058" class="btn-primary-text" text-anchor="middle">Start Your Assessment</text></a>
    </g>

  </g>
</svg>
```

## PUB-02_768.svg

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 768 1580" width="768" height="1580">
  <rect width="768" height="1580" fill="#FAFAF8"/>
  <defs>
    <style>
      .header-bg{fill:#1A2A4A}.hero-bg{fill:url(#h)}.text-white{fill:#FFF;font-family:Inter,Arial,sans-serif}.text-primary{fill:#1A2A4A;font-family:Inter,Arial,sans-serif}.text-secondary{fill:#6B7280;font-family:Inter,Arial,sans-serif}.btn-primary{fill:#1A2A4A}.btn-primary-text{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:16px;font-weight:600}.btn-secondary-light{fill:none;stroke:#1A2A4A;stroke-width:2}.btn-secondary-text-light{fill:#1A2A4A;font-family:Inter,Arial,sans-serif;font-size:16px;font-weight:600}.card{fill:#FFF;stroke:#D8DEE8;stroke-width:1}.card-title{fill:#1A2A4A;font-family:Inter,Arial,sans-serif;font-size:16px;font-weight:600}.card-desc{fill:#6B7280;font-family:Inter,Arial,sans-serif;font-size:16px}.privacy-badge{fill:#F3F4F6}.privacy-text{fill:#1A2A4A;font-family:Inter,Arial,sans-serif;font-size:16px;font-weight:500}.footer-bg{fill:#1A2A4A}.footer-title{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:16px;font-weight:600}.footer-link{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:16px}.footer-line{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:16px}.footer-version{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:14px}.h1-text{fill:#1A2A4A;font-family:Inter,Arial,sans-serif;font-size:34px;font-weight:700}.h1-white{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:34px;font-weight:700}.body-text{fill:#6B7280;font-family:Inter,Arial,sans-serif;font-size:16px}.body-white{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:16px}.skip-link{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:14px;font-weight:600}.step-number{fill:#1A2A4A;font-family:Inter,Arial,sans-serif;font-size:20px;font-weight:700}
    </style>
    <linearGradient id="h" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#1A2A4A"/><stop offset="100%" stop-color="#2A4060"/></linearGradient>
    <symbol id="roots-wordmark-dark" viewBox="0 0 126 30">
      <g transform="translate(0 5)" fill="#FFFFFF">
        <path d="M0 20V0h10c3 0 6 2 6 6 0 3-2 5-5 6l5 8h-4l-4-7H4v7H0Zm4-16v6h5c2 0 3-1 3-3s-1-3-3-3H4Z"/>
        <path d="M20 10c0-6 2-10 7-10s7 4 7 10-2 10-7 10-7-4-7-10Zm4 0c0 4 1 7 3 7s3-3 3-7-1-7-3-7-3 3-3 7Z"/>
        <path d="M38 10c0-6 2-10 7-10s7 4 7 10-2 10-7 10-7-4-7-10Zm4 0c0 4 1 7 3 7s3-3 3-7-1-7-3-7-3 3-3 7Z"/>
        <path d="M56 0v4h3v16h4V4h3V0H56Z"/>
        <path d="M75 0h-6v4h4v3l-4 1v7c0 3 1 5 4 5h4v-4h-4v-3l4-1V5c0-3-1-5-4-5h2Z"/>
        <path d="M80 9h6v2h-6Z"/>
        <path d="M90 20 94 0h5l4 20h-4l-2-7h-3l-2 7h-2Zm5-16v6h1l-1-6Z"/>
        <path d="M105 0h4v20h-4Z"/>
      </g>
      <g transform="translate(113 6) scale(.55)" fill="#D8DEE8">
        <path d="M0 0H7V1.6H4.3V8H2.7V1.6H0Z"/>
        <path d="M8.5 0H10.5L12.7 4.8L14.9 0H16.9V8H15.3V2.7L13.4 6.7H12L10.1 2.7V8H8.5Z"/>
      </g>
    </symbol>
    <symbol id="roots-wordmark-footer" viewBox="0 0 126 30">
      <g transform="translate(0 5)" fill="#FFFFFF">
        <path d="M0 20V0h10c3 0 6 2 6 6 0 3-2 5-5 6l5 8h-4l-4-7H4v7H0Zm4-16v6h5c2 0 3-1 3-3s-1-3-3-3H4Z"/>
        <path d="M20 10c0-6 2-10 7-10s7 4 7 10-2 10-7 10-7-4-7-10Zm4 0c0 4 1 7 3 7s3-3 3-7-1-7-3-7-3 3-3 7Z"/>
        <path d="M38 10c0-6 2-10 7-10s7 4 7 10-2 10-7 10-7-4-7-10Zm4 0c0 4 1 7 3 7s3-3 3-7-1-7-3-7-3 3-3 7Z"/>
        <path d="M56 0v4h3v16h4V4h3V0H56Z"/>
        <path d="M75 0h-6v4h4v3l-4 1v7c0 3 1 5 4 5h4v-4h-4v-3l4-1V5c0-3-1-5-4-5h2Z"/>
        <path d="M80 9h6v2h-6Z"/>
        <path d="M90 20 94 0h5l4 20h-4l-2-7h-3l-2 7h-2Zm5-16v6h1l-1-6Z"/>
        <path d="M105 0h4v20h-4Z"/>
      </g>
      <g transform="translate(113 6) scale(.55)" fill="#D8DEE8">
        <path d="M0 0H7V1.6H4.3V8H2.7V1.6H0Z"/>
        <path d="M8.5 0H10.5L12.7 4.8L14.9 0H16.9V8H15.3V2.7L13.4 6.7H12L10.1 2.7V8H8.5Z"/>
      </g>
    </symbol>
  </defs>
  <title>ROOTS-AI How It Works - 768</title>
  <desc>How It Works page. PUB-02, Size:768px.</desc>
  <a href="#main"><rect x="10" y="10" width="180" height="44" rx="8" fill="#1A2A4A"/><text x="100" y="38" class="skip-link" text-anchor="middle">Skip to content</text></a>

  <g data-screen-id="PUB-02" data-path="/how-it-works" data-permission="public" data-size="768">

    <!-- HEADER - Mobile: Logo + Start button + Hamburger -->
    <g id="header" data-sticky-trigger="80"><rect class="header-bg" x="0" y="0" width="768" height="64"/>
      <a href="/"><use href="#roots-wordmark-dark" x="20" y="17" width="118" height="28"/></a>
      <a href="/assessment"><rect x="552" y="10" width="148" height="44" rx="8" fill="#FFFFFF"/><text x="626" y="37" class="text-primary" font-size="14px" font-weight="600" text-anchor="middle">Start Assessment</text></a>
      <g id="hamburger" data-state="closed" style="display:block"><rect x="710" y="10" width="44" height="44" rx="8" fill="#FFF" fill-opacity="0.05"/><rect x="720" y="22" width="24" height="3" rx="1.5" fill="#FFF"/><rect x="720" y="30" width="24" height="3" rx="1.5" fill="#FFF"/><rect x="720" y="38" width="24" height="3" rx="1.5" fill="#FFF"/></g>
    </g>

    <!-- MAIN CONTENT -->
    <g id="main">

    <!-- ZONE 1: INTRO -->
    <g id="intro" data-zone="intro">
      <rect class="hero-bg" x="0" y="64" width="768" height="180"/>
      <text x="384" y="130" class="h1-white" text-anchor="middle">From Answers to Biological Intelligence</text>
      <text x="384" y="190" class="body-white" text-anchor="middle" font-size="16px">ROOTS-AI™ follows a controlled sequence so that interpretation never replaces the underlying data.</text>
    </g>

    <!-- ZONE 2: FOUR-STEP PROCESS - 2 columns, 4 cards -->
    <g id="process" data-zone="process">
      <text x="384" y="300" class="h1-text" text-anchor="middle" font-size="30px">The Process</text>

      <g id="step-1" data-component="step-card" data-step="1">
        <rect x="30" y="330" width="340" height="140" rx="12" class="card"/>
        <text x="60" y="360" class="step-number" text-anchor="middle">1</text>
        <text x="100" y="365" class="card-title" text-anchor="start" font-size="16px">
          <tspan x="100" dy="0">Complete the 73-question</tspan>
          <tspan x="100" dy="22">assessment.</tspan>
        </text>
        <text x="100" y="415" class="card-desc" text-anchor="start" font-size="16px">
          <tspan x="100" dy="0">Validation normalizes approved</tspan>
          <tspan x="100" dy="22">responses and preserves N/A.</tspan>
        </text>
      </g>

      <g id="step-2" data-component="step-card" data-step="2">
        <rect x="400" y="330" width="340" height="140" rx="12" class="card"/>
        <text x="430" y="360" class="step-number" text-anchor="middle">2</text>
        <text x="470" y="365" class="card-title" text-anchor="start" font-size="16px">
          <tspan x="470" dy="0">Deterministic rules calculate</tspan>
          <tspan x="470" dy="22">seven domains and derived</tspan>
          <tspan x="470" dy="22">indicators.</tspan>
        </text>
        <text x="470" y="415" class="card-desc" text-anchor="start" font-size="16px">
          <tspan x="470" dy="0">Rules select drivers, confidence</tspan>
          <tspan x="470" dy="22">and eligible content.</tspan>
        </text>
      </g>

      <g id="step-3" data-component="step-card" data-step="3">
        <rect x="30" y="490" width="340" height="80" rx="12" class="card"/>
        <text x="60" y="520" class="step-number" text-anchor="middle">3</text>
        <text x="100" y="525" class="card-title" text-anchor="start" font-size="16px">
          <tspan x="100" dy="0">Governed AI turns approved</tspan>
          <tspan x="100" dy="22">explanation objects into clear</tspan>
          <tspan x="100" dy="22">language.</tspan>
        </text>
      </g>

      <g id="step-4" data-component="step-card" data-step="4">
        <rect x="400" y="490" width="340" height="80" rx="12" class="card"/>
        <text x="430" y="520" class="step-number" text-anchor="middle">4</text>
        <text x="470" y="525" class="card-title" text-anchor="start" font-size="16px">
          <tspan x="470" dy="0">The web and PDF reports</tspan>
          <tspan x="470" dy="22">render from the same immutable</tspan>
          <tspan x="470" dy="22">report record.</tspan>
        </text>
      </g>
    </g>

    <!-- ZONE 3: WHAT AI DOES -->
    <g id="ai-does" data-zone="ai-does">
      <rect x="30" y="610" width="340" height="50" rx="12" fill="#F3F4F6"/>
      <text x="200" y="642" class="privacy-text" text-anchor="middle" font-size="16px" font-weight="600">✓ AI assists with language generation only.</text>
    </g>

    <!-- ZONE 4: WHAT AI DOES NOT -->
    <g id="ai-does-not" data-zone="ai-does-not">
      <rect x="400" y="610" width="340" height="70" rx="12" fill="#F3F4F6"/>
      <text x="570" y="635" class="privacy-text" text-anchor="middle" font-size="16px">AI does not diagnose, prescribe,</text>
      <text x="570" y="660" class="privacy-text" text-anchor="middle" font-size="16px">change scores, or invent participant facts.</text>
    </g>

    <!-- ZONE 5: PRIVACY BLOCK -->
    <g id="privacy" data-zone="privacy">
      <rect x="30" y="710" width="710" height="50" rx="12" class="card"/>
      <text x="385" y="742" class="privacy-text" text-anchor="middle" font-size="16px" font-weight="600">🔒 Secure access and data controls</text>
    </g>

    <!-- ZONE 6: CTA -->
    <g id="cta" data-zone="cta">
      <a href="/assessment"><rect x="184" y="800" width="200" height="44" rx="8" class="btn-primary"/><text x="284" y="828" class="btn-primary-text" text-anchor="middle">Start Your Assessment</text></a>
      <a href="/example-report"><rect x="400" y="800" width="180" height="44" rx="8" class="btn-secondary-light"/><text x="490" y="828" class="btn-secondary-text-light" text-anchor="middle">View Example Report</text></a>
    </g>

    </g>

    <!-- FOOTER - C-05 Groups -->
    <g id="footer" data-zone="footer">
      <rect class="footer-bg" x="0" y="900" width="768" height="680" rx="0"/>
      
      <!-- Product -->
      <g id="footer-product"><text x="40" y="940" class="footer-title">Product</text>
        <a href="/how-it-works"><rect x="20" y="955" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="100" y="985" class="footer-link">How It Works</text></a>
        <a href="/platform"><rect x="20" y="1005" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="100" y="1035" class="footer-link">Platform</text></a>
        <a href="/example-report"><rect x="20" y="1055" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="100" y="1085" class="footer-link">Example Report</text></a>
        <a href="/assessment"><rect x="20" y="1105" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="100" y="1135" class="footer-link">Start Assessment</text></a></g>
      
      <!-- Research -->
      <g id="footer-research"><text x="284" y="940" class="footer-title">Research</text>
        <a href="/research"><rect x="264" y="955" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="344" y="985" class="footer-link">Research</text></a>
        <a href="/pilot"><rect x="264" y="1005" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="344" y="1035" class="footer-link">Pilot Program</text></a>
        <a href="/healthcare-professionals"><rect x="264" y="1055" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="344" y="1085" class="footer-link">Healthcare Professionals</text></a></g>
      
      <!-- Company -->
      <g id="footer-company"><text x="528" y="940" class="footer-title">Company</text>
        <a href="/about"><rect x="508" y="955" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="588" y="985" class="footer-link">About</text></a>
        <a href="/blog"><rect x="508" y="1005" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="588" y="1035" class="footer-link">Blog</text></a>
        <a href="/contact"><rect x="508" y="1055" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="588" y="1085" class="footer-link">Contact</text></a></g>
      
      <!-- Legal -->
      <g id="footer-legal"><text x="40" y="1160" class="footer-title">Legal</text>
        <a href="/privacy"><rect x="20" y="1175" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="100" y="1205" class="footer-link">Privacy</text></a>
        <a href="/terms"><rect x="20" y="1225" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="100" y="1255" class="footer-link">Terms</text></a>
        <a href="/cookies"><rect x="20" y="1275" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="100" y="1305" class="footer-link">Cookies</text></a>
        <a href="/medical-disclaimer"><rect x="20" y="1325" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="100" y="1355" class="footer-link">Medical Disclaimer</text></a>
        <a href="/ai-disclaimer"><rect x="20" y="1375" width="160" height="44" fill="#FFF" fill-opacity="0"/><text x="100" y="1405" class="footer-link">AI Disclaimer</text></a></g>
      
      <g id="footer-base">
        <use href="#roots-wordmark-footer" x="321" y="1430" width="126" height="30"/>
        <text x="384" y="1490" class="footer-line" text-anchor="middle">© 2026 ROOTS AI HEALTH SYSTEMS, Inc. All rights reserved.</text>
        <text x="384" y="1518" class="footer-line" text-anchor="middle">ROOTS-AI™ provides educational wellness information and does not diagnose or treat medical conditions.</text>
        <text x="384" y="1550" class="footer-version" text-anchor="middle">Build: v1.0.0</text>
      </g>
    </g>

    <!-- DRAWER -->
    <g id="drawer" data-state="closed" style="display:none;pointer-events:none;"><rect x="0" y="0" width="768" height="1580" fill="#1A2A4A" fill-opacity="0.95"/>
      <text x="384" y="60" class="text-white" font-size="24px" font-weight="700" text-anchor="middle">ROOTS-AI™</text>
      <rect x="710" y="10" width="44" height="44" rx="8" fill="#FFF" fill-opacity="0.1"/><text x="732" y="38" class="text-white" font-size="20px" text-anchor="middle">✕</text>
      <a href="/"><rect x="284" y="100" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="384" y="130" class="text-white" font-size="20px" text-anchor="middle">Home</text></a>
      <a href="/how-it-works"><rect x="284" y="155" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="384" y="185" class="text-white" font-size="20px" text-anchor="middle">How It Works</text></a>
      <a href="/platform"><rect x="284" y="210" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="384" y="240" class="text-white" font-size="20px" text-anchor="middle">Platform</text></a>
      <a href="/example-report"><rect x="284" y="265" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="384" y="295" class="text-white" font-size="20px" text-anchor="middle">Example Report</text></a>
      <a href="/research"><rect x="284" y="320" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="384" y="350" class="text-white" font-size="20px" text-anchor="middle">Research</text></a>
      <a href="/about"><rect x="284" y="375" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="384" y="405" class="text-white" font-size="20px" text-anchor="middle">About</text></a>
      <rect x="0" y="450" width="768" height="1" fill="#FFF" fill-opacity="0.2"/>
      <a href="/healthcare-professionals"><rect x="284" y="470" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="384" y="500" class="text-white" font-size="20px" text-anchor="middle">Healthcare Professionals</text></a>
      <a href="/pilot"><rect x="284" y="525" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="384" y="555" class="text-white" font-size="20px" text-anchor="middle">Pilot Program</text></a>
      <a href="/contact"><rect x="284" y="580" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="384" y="610" class="text-white" font-size="20px" text-anchor="middle">Contact</text></a>
      <a href="/blog"><rect x="284" y="635" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="384" y="665" class="text-white" font-size="20px" text-anchor="middle">Blog</text></a>
      <rect x="0" y="710" width="768" height="1" fill="#FFF" fill-opacity="0.2"/>
      <a href="/privacy"><rect x="284" y="730" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="384" y="760" class="text-white" font-size="20px" text-anchor="middle">Privacy</text></a>
      <a href="/terms"><rect x="284" y="785" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="384" y="815" class="text-white" font-size="20px" text-anchor="middle">Terms</text></a>
      <a href="/cookies"><rect x="284" y="840" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="384" y="870" class="text-white" font-size="20px" text-anchor="middle">Cookies</text></a>
      <a href="/medical-disclaimer"><rect x="284" y="895" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="384" y="925" class="text-white" font-size="20px" text-anchor="middle">Medical Disclaimer</text></a>
      <a href="/ai-disclaimer"><rect x="284" y="950" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="384" y="980" class="text-white" font-size="20px" text-anchor="middle">AI Disclaimer</text></a>
      <a href="/assessment"><rect x="284" y="1030" width="200" height="44" rx="8" class="btn-primary"/><text x="384" y="1058" class="btn-primary-text" text-anchor="middle">Start Your Assessment</text></a>
    </g>

  </g>
</svg>
```

## PUB-02_1024.svg

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1490" width="1024" height="1490">
  <rect width="1024" height="1490" fill="#FAFAF8"/>
  <defs>
    <style>
      .header-bg{fill:#1A2A4A}.hero-bg{fill:url(#h)}.text-white{fill:#FFF;font-family:Inter,Arial,sans-serif}.text-primary{fill:#1A2A4A;font-family:Inter,Arial,sans-serif}.text-secondary{fill:#6B7280;font-family:Inter,Arial,sans-serif}.btn-primary{fill:#1A2A4A}.btn-primary-text{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:16px;font-weight:600}.btn-secondary-light{fill:none;stroke:#1A2A4A;stroke-width:2}.btn-secondary-text-light{fill:#1A2A4A;font-family:Inter,Arial,sans-serif;font-size:16px;font-weight:600}.card{fill:#FFF;stroke:#D8DEE8;stroke-width:1}.card-title{fill:#1A2A4A;font-family:Inter,Arial,sans-serif;font-size:16px;font-weight:600}.card-desc{fill:#6B7280;font-family:Inter,Arial,sans-serif;font-size:16px}.privacy-badge{fill:#F3F4F6}.privacy-text{fill:#1A2A4A;font-family:Inter,Arial,sans-serif;font-size:16px;font-weight:500}.footer-bg{fill:#1A2A4A}.footer-title{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:16px;font-weight:600}.footer-link{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:16px}.footer-line{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:16px}.footer-version{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:14px}.h1-text{fill:#1A2A4A;font-family:Inter,Arial,sans-serif;font-size:34px;font-weight:700}.h1-white{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:48px;font-weight:700}.body-text{fill:#6B7280;font-family:Inter,Arial,sans-serif;font-size:16px}.body-white{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:16px}.skip-link{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:14px;font-weight:600}.step-number{fill:#1A2A4A;font-family:Inter,Arial,sans-serif;font-size:22px;font-weight:700}
    </style>
    <linearGradient id="h" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#1A2A4A"/><stop offset="100%" stop-color="#2A4060"/></linearGradient>
    <symbol id="roots-wordmark-dark" viewBox="0 0 126 30">
      <g transform="translate(0 5)" fill="#FFFFFF">
        <path d="M0 20V0h10c3 0 6 2 6 6 0 3-2 5-5 6l5 8h-4l-4-7H4v7H0Zm4-16v6h5c2 0 3-1 3-3s-1-3-3-3H4Z"/>
        <path d="M20 10c0-6 2-10 7-10s7 4 7 10-2 10-7 10-7-4-7-10Zm4 0c0 4 1 7 3 7s3-3 3-7-1-7-3-7-3 3-3 7Z"/>
        <path d="M38 10c0-6 2-10 7-10s7 4 7 10-2 10-7 10-7-4-7-10Zm4 0c0 4 1 7 3 7s3-3 3-7-1-7-3-7-3 3-3 7Z"/>
        <path d="M56 0v4h3v16h4V4h3V0H56Z"/>
        <path d="M75 0h-6v4h4v3l-4 1v7c0 3 1 5 4 5h4v-4h-4v-3l4-1V5c0-3-1-5-4-5h2Z"/>
        <path d="M80 9h6v2h-6Z"/>
        <path d="M90 20 94 0h5l4 20h-4l-2-7h-3l-2 7h-2Zm5-16v6h1l-1-6Z"/>
        <path d="M105 0h4v20h-4Z"/>
      </g>
      <g transform="translate(113 6) scale(.55)" fill="#D8DEE8">
        <path d="M0 0H7V1.6H4.3V8H2.7V1.6H0Z"/>
        <path d="M8.5 0H10.5L12.7 4.8L14.9 0H16.9V8H15.3V2.7L13.4 6.7H12L10.1 2.7V8H8.5Z"/>
      </g>
    </symbol>
    <symbol id="roots-wordmark-footer" viewBox="0 0 126 30">
      <g transform="translate(0 5)" fill="#FFFFFF">
        <path d="M0 20V0h10c3 0 6 2 6 6 0 3-2 5-5 6l5 8h-4l-4-7H4v7H0Zm4-16v6h5c2 0 3-1 3-3s-1-3-3-3H4Z"/>
        <path d="M20 10c0-6 2-10 7-10s7 4 7 10-2 10-7 10-7-4-7-10Zm4 0c0 4 1 7 3 7s3-3 3-7-1-7-3-7-3 3-3 7Z"/>
        <path d="M38 10c0-6 2-10 7-10s7 4 7 10-2 10-7 10-7-4-7-10Zm4 0c0 4 1 7 3 7s3-3 3-7-1-7-3-7-3 3-3 7Z"/>
        <path d="M56 0v4h3v16h4V4h3V0H56Z"/>
        <path d="M75 0h-6v4h4v3l-4 1v7c0 3 1 5 4 5h4v-4h-4v-3l4-1V5c0-3-1-5-4-5h2Z"/>
        <path d="M80 9h6v2h-6Z"/>
        <path d="M90 20 94 0h5l4 20h-4l-2-7h-3l-2 7h-2Zm5-16v6h1l-1-6Z"/>
        <path d="M105 0h4v20h-4Z"/>
      </g>
      <g transform="translate(113 6) scale(.55)" fill="#D8DEE8">
        <path d="M0 0H7V1.6H4.3V8H2.7V1.6H0Z"/>
        <path d="M8.5 0H10.5L12.7 4.8L14.9 0H16.9V8H15.3V2.7L13.4 6.7H12L10.1 2.7V8H8.5Z"/>
      </g>
    </symbol>
  </defs>
  <title>ROOTS-AI How It Works - 1024</title>
  <desc>How It Works page. PUB-02, Size:1024px.</desc>
  <a href="#main"><rect x="10" y="10" width="180" height="44" rx="8" fill="#1A2A4A"/><text x="100" y="38" class="skip-link" text-anchor="middle">Skip to content</text></a>

  <g data-screen-id="PUB-02" data-path="/how-it-works" data-permission="public" data-size="1024">

    <!-- HEADER - Desktop: Logo, Nav with More, Start Assessment -->
    <g id="header" data-sticky-trigger="80"><rect class="header-bg" x="0" y="0" width="1024" height="72"/>
      <a href="/"><use href="#roots-wordmark-dark" x="30" y="21" width="118" height="28"/></a>
      <g id="nav">
        <a href="/how-it-works" aria-current="page"><rect x="200" y="14" width="100" height="44" fill="#FFF" fill-opacity="0"/><text x="250" y="42" class="text-white" font-size="14px" font-weight="600" text-anchor="middle">How It Works</text><rect x="200" y="67" width="100" height="3" rx="1.5" fill="#FFFFFF"/></a>
        <a href="/platform"><rect x="310" y="14" width="80" height="44" fill="#FFF" fill-opacity="0"/><text x="350" y="42" class="text-white" font-size="14px" font-weight="500" text-anchor="middle">Platform</text></a>
        <a href="/example-report"><rect x="400" y="14" width="120" height="44" fill="#FFF" fill-opacity="0"/><text x="460" y="42" class="text-white" font-size="14px" font-weight="500" text-anchor="middle">Example Report</text></a>
        <a href="/research"><rect x="530" y="14" width="80" height="44" fill="#FFF" fill-opacity="0"/><text x="570" y="42" class="text-white" font-size="14px" font-weight="500" text-anchor="middle">Research</text></a>
        <a href="/about"><rect x="620" y="14" width="60" height="44" fill="#FFF" fill-opacity="0"/><text x="650" y="42" class="text-white" font-size="14px" font-weight="500" text-anchor="middle">About</text></a>
        <!-- More dropdown -->
        <g id="nav-more" data-control="menu" data-state="closed" data-menu-target="public-more-menu" aria-label="More public navigation"><rect x="690" y="14" width="114" height="44" rx="8" fill="#FFF" fill-opacity="0"/><text x="720" y="42" class="text-white" font-size="14px" font-weight="500" text-anchor="middle">More</text><text x="782" y="42" class="text-white" font-size="18px" text-anchor="middle">▼</text></g>
        <g id="public-more-menu" data-state="closed" visibility="hidden">
          <a href="/healthcare-professionals"><text x="700" y="100" class="text-primary" font-size="16px">Healthcare Professionals</text></a>
          <a href="/pilot"><text x="700" y="130" class="text-primary" font-size="16px">Pilot Program</text></a>
          <a href="/blog"><text x="700" y="160" class="text-primary" font-size="16px">Blog</text></a>
          <a href="/contact"><text x="700" y="190" class="text-primary" font-size="16px">Contact</text></a>
        </g>
      </g>
      <a href="/assessment"><rect x="850" y="14" width="160" height="44" rx="8" fill="#FFFFFF"/><text x="930" y="42" class="text-primary" font-size="14px" font-weight="600" text-anchor="middle">Start Your Assessment</text></a>
    </g>

    <!-- MAIN CONTENT -->
    <g id="main">

    <!-- ZONE 1: INTRO -->
    <g id="intro" data-zone="intro">
      <rect class="hero-bg" x="0" y="72" width="1024" height="160"/>
      <text x="512" y="130" class="h1-white" text-anchor="middle">From Answers to Biological Intelligence</text>
      <text x="512" y="190" class="body-white" text-anchor="middle" font-size="16px">ROOTS-AI™ follows a controlled sequence so that interpretation never replaces the underlying data.</text>
    </g>

    <!-- ZONE 2: FOUR-STEP PROCESS - 4 columns -->
    <g id="process" data-zone="process">
      <text x="512" y="290" class="h1-text" text-anchor="middle" font-size="30px">The Process</text>

      <g id="step-1" data-component="step-card" data-step="1">
        <rect x="40" y="320" width="220" height="150" rx="12" class="card"/>
        <text x="70" y="350" class="step-number" text-anchor="middle">1</text>
        <text x="100" y="355" class="card-title" text-anchor="start" font-size="16px">
          <tspan x="100" dy="0">Complete the</tspan>
          <tspan x="100" dy="22">73-question</tspan>
          <tspan x="100" dy="22">assessment.</tspan>
        </text>
        <text x="100" y="415" class="card-desc" text-anchor="start" font-size="16px">
          <tspan x="100" dy="0">Validation normalizes</tspan>
          <tspan x="100" dy="22">approved responses</tspan>
          <tspan x="100" dy="22">and preserves N/A.</tspan>
        </text>
      </g>

      <g id="step-2" data-component="step-card" data-step="2">
        <rect x="275" y="320" width="220" height="150" rx="12" class="card"/>
        <text x="305" y="350" class="step-number" text-anchor="middle">2</text>
        <text x="335" y="355" class="card-title" text-anchor="start" font-size="16px">
          <tspan x="335" dy="0">Deterministic rules</tspan>
          <tspan x="335" dy="22">calculate seven</tspan>
          <tspan x="335" dy="22">domains and derived</tspan>
          <tspan x="335" dy="22">indicators.</tspan>
        </text>
        <text x="335" y="415" class="card-desc" text-anchor="start" font-size="16px">
          <tspan x="335" dy="0">Rules select drivers,</tspan>
          <tspan x="335" dy="22">confidence and</tspan>
          <tspan x="335" dy="22">eligible content.</tspan>
        </text>
      </g>

      <g id="step-3" data-component="step-card" data-step="3">
        <rect x="510" y="320" width="220" height="80" rx="12" class="card"/>
        <text x="540" y="350" class="step-number" text-anchor="middle">3</text>
        <text x="570" y="355" class="card-title" text-anchor="start" font-size="16px">
          <tspan x="570" dy="0">Governed AI turns</tspan>
          <tspan x="570" dy="22">approved explanation</tspan>
          <tspan x="570" dy="22">objects into clear</tspan>
          <tspan x="570" dy="22">language.</tspan>
        </text>
      </g>

      <g id="step-4" data-component="step-card" data-step="4">
        <rect x="745" y="320" width="220" height="80" rx="12" class="card"/>
        <text x="775" y="350" class="step-number" text-anchor="middle">4</text>
        <text x="805" y="355" class="card-title" text-anchor="start" font-size="16px">
          <tspan x="805" dy="0">The web and PDF</tspan>
          <tspan x="805" dy="22">reports render from</tspan>
          <tspan x="805" dy="22">the same immutable</tspan>
          <tspan x="805" dy="22">report record.</tspan>
        </text>
      </g>
    </g>

    <!-- ZONE 3: WHAT AI DOES -->
    <g id="ai-does" data-zone="ai-does">
      <rect x="40" y="510" width="460" height="50" rx="12" fill="#F3F4F6"/>
      <text x="270" y="542" class="privacy-text" text-anchor="middle" font-size="16px" font-weight="600">✓ AI assists with language generation only.</text>
    </g>

    <!-- ZONE 4: WHAT AI DOES NOT -->
    <g id="ai-does-not" data-zone="ai-does-not">
      <rect x="520" y="510" width="460" height="70" rx="12" fill="#F3F4F6"/>
      <text x="750" y="535" class="privacy-text" text-anchor="middle" font-size="16px">AI does not diagnose, prescribe,</text>
      <text x="750" y="560" class="privacy-text" text-anchor="middle" font-size="16px">change scores, or invent participant facts.</text>
    </g>

    <!-- ZONE 5: PRIVACY BLOCK -->
    <g id="privacy" data-zone="privacy">
      <rect x="40" y="610" width="940" height="50" rx="12" class="card"/>
      <text x="510" y="642" class="privacy-text" text-anchor="middle" font-size="16px" font-weight="600">🔒 Secure access and data controls</text>
    </g>

    <!-- ZONE 6: CTA -->
    <g id="cta" data-zone="cta">
      <a href="/assessment"><rect x="300" y="700" width="200" height="44" rx="8" class="btn-primary"/><text x="400" y="728" class="btn-primary-text" text-anchor="middle">Start Your Assessment</text></a>
      <a href="/example-report"><rect x="520" y="700" width="200" height="44" rx="8" class="btn-secondary-light"/><text x="620" y="728" class="btn-secondary-text-light" text-anchor="middle">View Example Report</text></a>
    </g>

    </g>

    <!-- FOOTER - C-05 Groups -->
    <g id="footer" data-zone="footer">
      <rect class="footer-bg" x="0" y="800" width="1024" height="690" rx="0"/>
      
      <!-- Product -->
      <g id="footer-product"><text x="40" y="840" class="footer-title">Product</text>
        <a href="/how-it-works"><rect x="20" y="855" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="120" y="885" class="footer-link">How It Works</text></a>
        <a href="/platform"><rect x="20" y="905" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="120" y="935" class="footer-link">Platform</text></a>
        <a href="/example-report"><rect x="20" y="955" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="120" y="985" class="footer-link">Example Report</text></a>
        <a href="/assessment"><rect x="20" y="1005" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="120" y="1035" class="footer-link">Start Assessment</text></a></g>
      
      <!-- Research -->
      <g id="footer-research"><text x="340" y="840" class="footer-title">Research</text>
        <a href="/research"><rect x="320" y="855" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="420" y="885" class="footer-link">Research</text></a>
        <a href="/pilot"><rect x="320" y="905" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="420" y="935" class="footer-link">Pilot Program</text></a>
        <a href="/healthcare-professionals"><rect x="320" y="955" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="420" y="985" class="footer-link">Healthcare Professionals</text></a></g>
      
      <!-- Company -->
      <g id="footer-company"><text x="660" y="840" class="footer-title">Company</text>
        <a href="/about"><rect x="640" y="855" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="740" y="885" class="footer-link">About</text></a>
        <a href="/blog"><rect x="640" y="905" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="740" y="935" class="footer-link">Blog</text></a>
        <a href="/contact"><rect x="640" y="955" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="740" y="985" class="footer-link">Contact</text></a></g>
      
      <!-- Legal -->
      <g id="footer-legal"><text x="40" y="1080" class="footer-title">Legal</text>
        <a href="/privacy"><rect x="20" y="1095" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="120" y="1125" class="footer-link">Privacy</text></a>
        <a href="/terms"><rect x="20" y="1145" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="120" y="1175" class="footer-link">Terms</text></a>
        <a href="/cookies"><rect x="20" y="1195" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="120" y="1225" class="footer-link">Cookies</text></a>
        <a href="/medical-disclaimer"><rect x="20" y="1245" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="120" y="1275" class="footer-link">Medical Disclaimer</text></a>
        <a href="/ai-disclaimer"><rect x="20" y="1295" width="200" height="44" fill="#FFF" fill-opacity="0"/><text x="120" y="1325" class="footer-link">AI Disclaimer</text></a></g>
      
      <g id="footer-base">
        <use href="#roots-wordmark-footer" x="449" y="1335" width="126" height="30"/>
        <text x="512" y="1395" class="footer-line" text-anchor="middle">© 2026 ROOTS AI HEALTH SYSTEMS, Inc. All rights reserved.</text>
        <text x="512" y="1423" class="footer-line" text-anchor="middle">ROOTS-AI™ provides educational wellness information and does not diagnose or treat medical conditions.</text>
        <text x="512" y="1455" class="footer-version" text-anchor="middle">Build: v1.0.0</text>
      </g>
    </g>

  </g>
</svg>
```

## PUB-02_1440.svg

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 1480" width="1440" height="1480">
  <rect width="1440" height="1480" fill="#FAFAF8"/>
  <defs>
    <style>
      .header-bg{fill:#1A2A4A}.hero-bg{fill:url(#h)}.text-white{fill:#FFF;font-family:Inter,Arial,sans-serif}.text-primary{fill:#1A2A4A;font-family:Inter,Arial,sans-serif}.text-secondary{fill:#6B7280;font-family:Inter,Arial,sans-serif}.btn-primary{fill:#1A2A4A}.btn-primary-text{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:16px;font-weight:600}.btn-secondary-light{fill:none;stroke:#1A2A4A;stroke-width:2}.btn-secondary-text-light{fill:#1A2A4A;font-family:Inter,Arial,sans-serif;font-size:16px;font-weight:600}.card{fill:#FFF;stroke:#D8DEE8;stroke-width:1}.card-title{fill:#1A2A4A;font-family:Inter,Arial,sans-serif;font-size:16px;font-weight:600}.card-desc{fill:#6B7280;font-family:Inter,Arial,sans-serif;font-size:16px}.privacy-badge{fill:#F3F4F6}.privacy-text{fill:#1A2A4A;font-family:Inter,Arial,sans-serif;font-size:16px;font-weight:500}.footer-bg{fill:#1A2A4A}.footer-title{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:16px;font-weight:600}.footer-link{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:16px}.footer-line{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:16px}.footer-version{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:14px}.h1-text{fill:#1A2A4A;font-family:Inter,Arial,sans-serif;font-size:34px;font-weight:700}.h1-white{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:48px;font-weight:700}.body-text{fill:#6B7280;font-family:Inter,Arial,sans-serif;font-size:16px}.body-white{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:16px}.skip-link{fill:#FFF;font-family:Inter,Arial,sans-serif;font-size:14px;font-weight:600}.step-number{fill:#1A2A4A;font-family:Inter,Arial,sans-serif;font-size:24px;font-weight:700}
    </style>
    <linearGradient id="h" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#1A2A4A"/><stop offset="100%" stop-color="#2A4060"/></linearGradient>
    <symbol id="roots-wordmark-dark" viewBox="0 0 126 30">
      <g transform="translate(0 5)" fill="#FFFFFF">
        <path d="M0 20V0h10c3 0 6 2 6 6 0 3-2 5-5 6l5 8h-4l-4-7H4v7H0Zm4-16v6h5c2 0 3-1 3-3s-1-3-3-3H4Z"/>
        <path d="M20 10c0-6 2-10 7-10s7 4 7 10-2 10-7 10-7-4-7-10Zm4 0c0 4 1 7 3 7s3-3 3-7-1-7-3-7-3 3-3 7Z"/>
        <path d="M38 10c0-6 2-10 7-10s7 4 7 10-2 10-7 10-7-4-7-10Zm4 0c0 4 1 7 3 7s3-3 3-7-1-7-3-7-3 3-3 7Z"/>
        <path d="M56 0v4h3v16h4V4h3V0H56Z"/>
        <path d="M75 0h-6v4h4v3l-4 1v7c0 3 1 5 4 5h4v-4h-4v-3l4-1V5c0-3-1-5-4-5h2Z"/>
        <path d="M80 9h6v2h-6Z"/>
        <path d="M90 20 94 0h5l4 20h-4l-2-7h-3l-2 7h-2Zm5-16v6h1l-1-6Z"/>
        <path d="M105 0h4v20h-4Z"/>
      </g>
      <g transform="translate(113 6) scale(.55)" fill="#D8DEE8">
        <path d="M0 0H7V1.6H4.3V8H2.7V1.6H0Z"/>
        <path d="M8.5 0H10.5L12.7 4.8L14.9 0H16.9V8H15.3V2.7L13.4 6.7H12L10.1 2.7V8H8.5Z"/>
      </g>
    </symbol>
    <symbol id="roots-wordmark-footer" viewBox="0 0 126 30">
      <g transform="translate(0 5)" fill="#FFFFFF">
        <path d="M0 20V0h10c3 0 6 2 6 6 0 3-2 5-5 6l5 8h-4l-4-7H4v7H0Zm4-16v6h5c2 0 3-1 3-3s-1-3-3-3H4Z"/>
        <path d="M20 10c0-6 2-10 7-10s7 4 7 10-2 10-7 10-7-4-7-10Zm4 0c0 4 1 7 3 7s3-3 3-7-1-7-3-7-3 3-3 7Z"/>
        <path d="M38 10c0-6 2-10 7-10s7 4 7 10-2 10-7 10-7-4-7-10Zm4 0c0 4 1 7 3 7s3-3 3-7-1-7-3-7-3 3-3 7Z"/>
        <path d="M56 0v4h3v16h4V4h3V0H56Z"/>
        <path d="M75 0h-6v4h4v3l-4 1v7c0 3 1 5 4 5h4v-4h-4v-3l4-1V5c0-3-1-5-4-5h2Z"/>
        <path d="M80 9h6v2h-6Z"/>
        <path d="M90 20 94 0h5l4 20h-4l-2-7h-3l-2 7h-2Zm5-16v6h1l-1-6Z"/>
        <path d="M105 0h4v20h-4Z"/>
      </g>
      <g transform="translate(113 6) scale(.55)" fill="#D8DEE8">
        <path d="M0 0H7V1.6H4.3V8H2.7V1.6H0Z"/>
        <path d="M8.5 0H10.5L12.7 4.8L14.9 0H16.9V8H15.3V2.7L13.4 6.7H12L10.1 2.7V8H8.5Z"/>
      </g>
    </symbol>
  </defs>
  <title>ROOTS-AI How It Works - 1440</title>
  <desc>How It Works page. PUB-02, Size:1440px.</desc>
  <a href="#main"><rect x="10" y="10" width="180" height="44" rx="8" fill="#1A2A4A"/><text x="100" y="38" class="skip-link" text-anchor="middle">Skip to content</text></a>

  <g data-screen-id="PUB-02" data-path="/how-it-works" data-permission="public" data-size="1440">

    <!-- HEADER - Desktop: Logo, Nav with More, Start Assessment -->
    <g id="header" data-sticky-trigger="80"><rect class="header-bg" x="0" y="0" width="1440" height="72"/>
      <a href="/"><use href="#roots-wordmark-dark" x="40" y="21" width="126" height="30"/></a>
      <g id="nav">
        <a href="/how-it-works" aria-current="page"><rect x="200" y="14" width="100" height="44" fill="#FFF" fill-opacity="0"/><text x="250" y="42" class="text-white" font-size="14px" font-weight="600" text-anchor="middle">How It Works</text><rect x="200" y="67" width="100" height="3" rx="1.5" fill="#FFFFFF"/></a>
        <a href="/platform"><rect x="310" y="14" width="80" height="44" fill="#FFF" fill-opacity="0"/><text x="350" y="42" class="text-white" font-size="14px" font-weight="500" text-anchor="middle">Platform</text></a>
        <a href="/example-report"><rect x="400" y="14" width="120" height="44" fill="#FFF" fill-opacity="0"/><text x="460" y="42" class="text-white" font-size="14px" font-weight="500" text-anchor="middle">Example Report</text></a>
        <a href="/research"><rect x="530" y="14" width="80" height="44" fill="#FFF" fill-opacity="0"/><text x="570" y="42" class="text-white" font-size="14px" font-weight="500" text-anchor="middle">Research</text></a>
        <a href="/about"><rect x="620" y="14" width="60" height="44" fill="#FFF" fill-opacity="0"/><text x="650" y="42" class="text-white" font-size="14px" font-weight="500" text-anchor="middle">About</text></a>
        <g id="nav-more" data-control="menu" data-state="closed" data-menu-target="public-more-menu" aria-label="More public navigation"><rect x="690" y="14" width="114" height="44" rx="8" fill="#FFF" fill-opacity="0"/><text x="720" y="42" class="text-white" font-size="14px" font-weight="500" text-anchor="middle">More</text><text x="782" y="42" class="text-white" font-size="18px" text-anchor="middle">▼</text></g>
        <g id="public-more-menu" data-state="closed" visibility="hidden">
          <a href="/healthcare-professionals"><text x="700" y="100" class="text-primary" font-size="16px">Healthcare Professionals</text></a>
          <a href="/pilot"><text x="700" y="130" class="text-primary" font-size="16px">Pilot Program</text></a>
          <a href="/blog"><text x="700" y="160" class="text-primary" font-size="16px">Blog</text></a>
          <a href="/contact"><text x="700" y="190" class="text-primary" font-size="16px">Contact</text></a>
        </g>
      </g>
      <a href="/assessment"><rect x="850" y="14" width="180" height="44" rx="8" fill="#FFFFFF"/><text x="940" y="42" class="text-primary" font-size="14px" font-weight="600" text-anchor="middle">Start Your Assessment</text></a>
    </g>

    <!-- MAIN CONTENT -->
    <g id="main">

    <!-- ZONE 1: INTRO -->
    <g id="intro" data-zone="intro">
      <rect class="hero-bg" x="0" y="72" width="1440" height="160"/>
      <text x="720" y="130" class="h1-white" text-anchor="middle">From Answers to Biological Intelligence</text>
      <text x="720" y="190" class="body-white" text-anchor="middle" font-size="16px">ROOTS-AI™ follows a controlled sequence so that interpretation never replaces the underlying data.</text>
    </g>

    <!-- ZONE 2: FOUR-STEP PROCESS - 4 columns -->
    <g id="process" data-zone="process">
      <text x="720" y="290" class="h1-text" text-anchor="middle" font-size="30px">The Process</text>

      <g id="step-1" data-component="step-card" data-step="1">
        <rect x="120" y="320" width="285" height="150" rx="12" class="card"/>
        <text x="150" y="350" class="step-number" text-anchor="middle">1</text>
        <text x="180" y="355" class="card-title" text-anchor="start" font-size="16px">
          <tspan x="180" dy="0">Complete the</tspan>
          <tspan x="180" dy="22">73-question</tspan>
          <tspan x="180" dy="22">assessment.</tspan>
        </text>
        <text x="180" y="415" class="card-desc" text-anchor="start" font-size="16px">
          <tspan x="180" dy="0">Validation normalizes</tspan>
          <tspan x="180" dy="22">approved responses</tspan>
          <tspan x="180" dy="22">and preserves N/A.</tspan>
        </text>
      </g>

      <g id="step-2" data-component="step-card" data-step="2">
        <rect x="420" y="320" width="285" height="150" rx="12" class="card"/>
        <text x="450" y="350" class="step-number" text-anchor="middle">2</text>
        <text x="480" y="355" class="card-title" text-anchor="start" font-size="16px">
          <tspan x="480" dy="0">Deterministic rules</tspan>
          <tspan x="480" dy="22">calculate seven</tspan>
          <tspan x="480" dy="22">domains and derived</tspan>
          <tspan x="480" dy="22">indicators.</tspan>
        </text>
        <text x="480" y="415" class="card-desc" text-anchor="start" font-size="16px">
          <tspan x="480" dy="0">Rules select drivers,</tspan>
          <tspan x="480" dy="22">confidence and</tspan>
          <tspan x="480" dy="22">eligible content.</tspan>
        </text>
      </g>

      <g id="step-3" data-component="step-card" data-step="3">
        <rect x="720" y="320" width="285" height="80" rx="12" class="card"/>
        <text x="750" y="350" class="step-number" text-anchor="middle">3</text>
        <text x="780" y="355" class="card-title" text-anchor="start" font-size="16px">
          <tspan x="780" dy="0">Governed AI turns</tspan>
          <tspan x="780" dy="22">approved explanation</tspan>
          <tspan x="780" dy="22">objects into clear</tspan>
          <tspan x="780" dy="22">language.</tspan>
        </text>
      </g>

      <g id="step-4" data-component="step-card" data-step="4">
        <rect x="1020" y="320" width="285" height="80" rx="12" class="card"/>
        <text x="1050" y="350" class="step-number" text-anchor="middle">4</text>
        <text x="1080" y="355" class="card-title" text-anchor="start" font-size="16px">
          <tspan x="1080" dy="0">The web and PDF</tspan>
          <tspan x="1080" dy="22">reports render from</tspan>
          <tspan x="1080" dy="22">the same immutable</tspan>
          <tspan x="1080" dy="22">report record.</tspan>
        </text>
      </g>
    </g>

    <!-- ZONE 3: WHAT AI DOES -->
    <g id="ai-does" data-zone="ai-does">
      <rect x="120" y="510" width="580" height="50" rx="12" fill="#F3F4F6"/>
      <text x="410" y="542" class="privacy-text" text-anchor="middle" font-size="16px" font-weight="600">✓ AI assists with language generation only.</text>
    </g>

    <!-- ZONE 4: WHAT AI DOES NOT -->
    <g id="ai-does-not" data-zone="ai-does-not">
      <rect x="720" y="510" width="580" height="70" rx="12" fill="#F3F4F6"/>
      <text x="1010" y="535" class="privacy-text" text-anchor="middle" font-size="16px">AI does not diagnose, prescribe,</text>
      <text x="1010" y="560" class="privacy-text" text-anchor="middle" font-size="16px">change scores, or invent participant facts.</text>
    </g>

    <!-- ZONE 5: PRIVACY BLOCK -->
    <g id="privacy" data-zone="privacy">
      <rect x="120" y="610" width="1200" height="50" rx="12" class="card"/>
      <text x="720" y="642" class="privacy-text" text-anchor="middle" font-size="16px" font-weight="600">🔒 Secure access and data controls</text>
    </g>

    <!-- ZONE 6: CTA -->
    <g id="cta" data-zone="cta">
      <a href="/assessment"><rect x="530" y="700" width="200" height="44" rx="8" class="btn-primary"/><text x="630" y="728" class="btn-primary-text" text-anchor="middle">Start Your Assessment</text></a>
      <a href="/example-report"><rect x="750" y="700" width="200" height="44" rx="8" class="btn-secondary-light"/><text x="850" y="728" class="btn-secondary-text-light" text-anchor="middle">View Example Report</text></a>
    </g>

    </g>

    <!-- FOOTER - C-05 Groups -->
    <g id="footer" data-zone="footer">
      <rect class="footer-bg" x="0" y="800" width="1440" height="680" rx="0"/>
      
      <!-- Product -->
      <g id="footer-product"><text x="120" y="840" class="footer-title">Product</text>
        <a href="/how-it-works"><rect x="100" y="855" width="220" height="44" fill="#FFF" fill-opacity="0"/><text x="210" y="885" class="footer-link">How It Works</text></a>
        <a href="/platform"><rect x="100" y="905" width="220" height="44" fill="#FFF" fill-opacity="0"/><text x="210" y="935" class="footer-link">Platform</text></a>
        <a href="/example-report"><rect x="100" y="955" width="220" height="44" fill="#FFF" fill-opacity="0"/><text x="210" y="985" class="footer-link">Example Report</text></a>
        <a href="/assessment"><rect x="100" y="1005" width="220" height="44" fill="#FFF" fill-opacity="0"/><text x="210" y="1035" class="footer-link">Start Assessment</text></a></g>
      
      <!-- Research -->
      <g id="footer-research"><text x="480" y="840" class="footer-title">Research</text>
        <a href="/research"><rect x="460" y="855" width="220" height="44" fill="#FFF" fill-opacity="0"/><text x="570" y="885" class="footer-link">Research</text></a>
        <a href="/pilot"><rect x="460" y="905" width="220" height="44" fill="#FFF" fill-opacity="0"/><text x="570" y="935" class="footer-link">Pilot Program</text></a>
        <a href="/healthcare-professionals"><rect x="460" y="955" width="220" height="44" fill="#FFF" fill-opacity="0"/><text x="570" y="985" class="footer-link">Healthcare Professionals</text></a></g>
      
      <!-- Company -->
      <g id="footer-company"><text x="880" y="840" class="footer-title">Company</text>
        <a href="/about"><rect x="860" y="855" width="220" height="44" fill="#FFF" fill-opacity="0"/><text x="970" y="885" class="footer-link">About</text></a>
        <a href="/blog"><rect x="860" y="905" width="220" height="44" fill="#FFF" fill-opacity="0"/><text x="970" y="935" class="footer-link">Blog</text></a>
        <a href="/contact"><rect x="860" y="955" width="220" height="44" fill="#FFF" fill-opacity="0"/><text x="970" y="985" class="footer-link">Contact</text></a></g>
      
      <!-- Legal -->
      <g id="footer-legal"><text x="120" y="1080" class="footer-title">Legal</text>
        <a href="/privacy"><rect x="100" y="1095" width="220" height="44" fill="#FFF" fill-opacity="0"/><text x="210" y="1125" class="footer-link">Privacy</text></a>
        <a href="/terms"><rect x="100" y="1145" width="220" height="44" fill="#FFF" fill-opacity="0"/><text x="210" y="1175" class="footer-link">Terms</text></a>
        <a href="/cookies"><rect x="100" y="1195" width="220" height="44" fill="#FFF" fill-opacity="0"/><text x="210" y="1225" class="footer-link">Cookies</text></a>
        <a href="/medical-disclaimer"><rect x="100" y="1245" width="220" height="44" fill="#FFF" fill-opacity="0"/><text x="210" y="1275" class="footer-link">Medical Disclaimer</text></a>
        <a href="/ai-disclaimer"><rect x="100" y="1295" width="220" height="44" fill="#FFF" fill-opacity="0"/><text x="210" y="1325" class="footer-link">AI Disclaimer</text></a></g>
      
      <g id="footer-base">
        <use href="#roots-wordmark-footer" x="657" y="1330" width="126" height="30"/>
        <text x="720" y="1390" class="footer-line" text-anchor="middle">© 2026 ROOTS AI HEALTH SYSTEMS, Inc. All rights reserved.</text>
        <text x="720" y="1418" class="footer-line" text-anchor="middle">ROOTS-AI™ provides educational wellness information and does not diagnose or treat medical conditions.</text>
        <text x="720" y="1450" class="footer-version" text-anchor="middle">Build: v1.0.0</text>
      </g>
    </g>

  </g>
</svg>
```

# ROOTS-AI™ — PUB-07 Pilot

Status: TECHNICAL HANDOFF READY
Route: /pilot
Screen ID: PUB-07

Included editable SVG frames:
- PUB-07_360.svg
- PUB-07_768.svg
- PUB-07_1024.svg
- PUB-07_1440.svg
- PUB-07_QA.md

Authority: C-04 controls exact public copy; C-05 controls composition, navigation, responsive behavior and screen acceptance.

Important: this package is an editable C-08 design handoff, not production UAT evidence. Browser compatibility, interaction wiring, accordion behavior, eligibility routing and staging screenshots remain implementation-stage acceptance items.

# ROOTS-AI™ — RPT-01 Report Access — QA / Implementation Notes

## Status
Technical Handoff Ready after static artifact checks. Formal production acceptance still requires browser/staging/security/E2E validation.

## Locked contract
- Route: `/report/[id]`
- Entry: Secure report link
- Access: Secure link holder
- Purpose: Authorize report access without exposing report existence.
- Verification: session/token validation.
- Loading: neutral secure loading.
- Expired/invalid: Request New Link / Contact Support without confirming whether a report exists.
- Success: automatic redirect to RPT-02 Interactive Report.
- C-02 controls report/scoring data.
- C-03 controls report sections/charts/report copy.
- C-04 controls access/system copy.
- C-05 controls composition/behavior.

## Critical invariants
- Do not expose participant identity, scores, report sections, report metadata, generation date, report contents, or download controls before successful authorization.
- Do not expose tokens, session identifiers, internal report IDs, internal DB IDs, stack traces, or sensitive backend error details.
- Failure UI must not distinguish existing report vs missing report in a way that enables enumeration.
- Download PDF and section navigation begin only after successful authorization.
- Secure report access must be private, authorized and audited.
- Authorized success redirects to RPT-02.

## Required states
- Verifying
- Authorized / redirecting
- Expired or invalid
- Service failure
- Offline

## Static QA performed
- XML parse: 4/4 PASS
- CairoSVG static render: 4/4 PASS
- Responsive artifacts: 360 / 768 / 1024 / 1440
- Official Phase 0B ROOTS-AI light-background wordmark embedded
- ZIP integrity: PASS

## Production checks still required
- Browser/staging visual QA at all breakpoints (static PNG visual inspection completed for 360 and 1440)
- Real token/session authorization
- Non-enumerating error behavior
- Authorized redirect to RPT-02
- Audit logging
- Offline/service-failure behavior
- Keyboard/focus/accessibility
- Security/E2E testing

# ROOTS-AI™ — RPT-04 PDF Preparation — QA / Implementation Contract

## Scope
RPT-04 PDF Preparation.
4 responsive SVG handoff files: 360 / 768 / 1024 / 1440.

## Locked contract
- Entry: Download action state
- Access: Authorized participant
- Purpose: Generate/download byte-authorized PDF from the same canonical report JSON.
- Trigger: Download PDF.
- Preparing: progress/spinner.
- Cancel UI: render only if backend/API supports cancellation.
- Ready: download starts and confirmation is shown.
- Failure: retry PDF preparation only; never regenerate scores.
- Support reference may be shown using approved implementation binding.
- Null/missing/narrative/PDF/access errors use approved deterministic/fixed copy.

## Canonical invariants
- Web and PDF must render from the same stored canonical JSON hash.
- All 19 sections remain in fixed order.
- Scores, drivers, classifications, versions, answers snapshot and disclaimer must match the canonical report.
- No null-value imputation.
- Every production chart requires labels/values plus a text equivalent.
- The PDF preparation action must not recalculate scoring or regenerate report data.

## Security / privacy
- Authorized session only.
- Do not expose signed URLs, storage paths, tokens, backend stack traces or internal object identifiers.
- Download authorization/audit logging must be enforced in implementation.

## Static QA performed
- XML parse: 4/4 PASS
- CairoSVG static render: 4/4 PASS
- Breakpoints generated: 360 / 768 / 1024 / 1440
- Official Phase 0B ROOTS-AI light-background wordmark embedded
- ZIP integrity: PASS
- Static PNG visual inspection completed: 360 and 1440

## Production validation still required
- Browser/staging visual regression at all four breakpoints.
- Real canonical JSON hash parity with generated PDF.
- Byte authorization and download response validation.
- Ready/download-start behavior.
- Retry behavior without score regeneration.
- Optional cancel behavior only when backend supports it.
- Keyboard/focus/screen-reader behavior.
- Offline/service failure behavior.
- PDF minimum/maximum-content page-break regression.

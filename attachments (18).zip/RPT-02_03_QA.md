# ROOTS-AI™ — RPT-02 / RPT-03 — QA & Implementation Contract

## Scope
RPT-02 Interactive Report + RPT-03 Report Section Navigation.
8 responsive SVG handoff files total: 360 / 768 / 1024 / 1440 for each screen.

## Locked RPT-02 contract
- Route: `/report/[id]`
- Access: Authorized participant
- Purpose: Render canonical 19-section report.
- Header: Report ID/version/date, Download PDF, secure sign-out.
- Cover: participant display or fallback Participant, educational badge.
- Summary metrics: Biological State, Opportunity, Recovery Potential, Confidence.
- All 19 sections exist in fixed order.
- Footer: version set, audit reference, disclaimer link.
- Null/missing content never imputed; approved deterministic/fixed fallback only.
- Full Medical and AI Disclaimer is rendered without truncation.
- Web and PDF must render from same stored canonical JSON hash.

## Locked RPT-03 contract
- Entry: within `/report/[id]`
- Access: Authorized participant
- Desktop: sticky left contents with 19 numbered links.
- Mobile: current-section control opens full-height section drawer.
- Active section: Intersection Observer + URL hash.
- Accessible Return to Top after section 3.
- Navigation must not alter report meaning or values.

## Visual / responsive rules
- Desktop body target 800 px + 240 px contents.
- Mobile single column.
- Score cards stack.
- Charts must retain labels and values and need text equivalents in production.

## Static QA performed
- XML parse: 8/8 PASS
- CairoSVG static render: 8/8 PASS
- Breakpoints generated: 360 / 768 / 1024 / 1440
- Official Phase 0B ROOTS-AI light-background wordmark embedded
- ZIP integrity: PASS
- Static PNG visual inspection completed: RPT-02 360/1440 and RPT-03 360/1440

## Production validation still required
- Browser/staging visual regression at all four breakpoints.
- Real canonical JSON binding and version/hash parity with PDF.
- Interactive section navigation, URL hash, Intersection Observer.
- Keyboard focus order, focus visibility, screen-reader labels, drawer focus trap/return focus.
- Real PDF download and secure sign-out.
- Security/authorization/audit logging.
- Null/missing/narrative fallback behavior with production data.
- Chart text-equivalent validation.

# ROOTS-AI™ — RPT-05 Report Access Error — QA / Implementation Contract

## Scope
RPT-05 Report Access Error.
4 responsive SVG handoff files: 360 / 768 / 1024 / 1440.

## Locked contract
- Route / entry: `/report/[id]` error state
- Access: Public / unauthorized
- Purpose: Handle not found, expired and forbidden safely.
- Message: generic secure-access failure.
- Actions: Request new secure link; Contact support; Home.
- Security: no participant name, report ID detail, score or report-existence confirmation.

## Copy governance
- C-04 controls system/access copy.
- Known expiry may use exact SESSION-EXPIRED copy:
  “For your security, this session has expired. Request a new secure link to continue.”
- Other not-found/forbidden/invalid cases use an approved secure-error copy/config binding; the SVG does not invent production error copy.

## Security firewall
Do not expose:
- participant name
- report ID detail
- score/classification/driver/domain data
- report sections or report-existence confirmation
- token or signed URL
- storage path/internal object key
- authorization decision detail
- backend exception/stack trace

## State contract
- generic_access_failure
- expired_session
- forbidden_or_invalid
- not_found
- service_unavailable

Backend may distinguish states internally. Visible UI remains non-enumerating except where an approved state-specific message is explicitly authorized.

## Accessibility / responsive implementation
- 360 / 768 / 1024 / 1440
- ≥44 px action targets
- logical keyboard order
- visible focus in implementation
- error status announced to assistive technology
- meaning must not depend on color alone

## Static QA performed
- XML parse: 4/4 PASS
- CairoSVG static render: 4/4 PASS
- Official Phase 0B ROOTS-AI light-background wordmark embedded
- No participant/report data bindings rendered
- ZIP integrity: PASS
- Static PNG visual inspection completed: 360 and 1440
- 360 containment issue found and corrected before final packaging

## Production validation still required
- Browser/staging visual regression at all four breakpoints.
- Authorization negative tests for expired/not-found/forbidden/invalid/service-failure states.
- Confirm response does not permit report enumeration.
- Request-new-link workflow validation.
- Contact/Home routing.
- Keyboard/focus/screen-reader validation.
- Audit/security logging validation.
